/** @odoo-module **/
/**
 * HRMIS Dashboard — Patch HomeMenus (thème Diwy)
 * ------------------------------------------------
 * Corrige :  TypeError: ctx.getIconClass is not a function
 *
 * Le template "theme_diwy.home_menus" appelle getIconClass(app)
 * mais la classe HomeMenus de Diwy ne la définit pas.
 * On l'injecte ici via patch().
 *
 * INSTALLATION
 *   1. Placez ce fichier dans :
 *        hrmis_dashboard/static/src/js/home_menu_patch.js
 *
 *   2. Dans __manifest__.py, ajoutez-le EN PREMIER dans web.assets_backend :
 *        'hrmis_dashboard/static/src/js/home_menu_patch.js',
 *
 *   3. Redémarrez Odoo + videz le cache navigateur (Ctrl+Shift+R)
 */

import { patch } from "@web/core/utils/patch";
import { HomeMenus } from "@theme_diwy/js/home_menus";

patch(HomeMenus.prototype, {

    /**
     * Retourne la classe CSS FontAwesome pour une app donnée.
     * Appelé par le template theme_diwy.home_menus sur chaque app.
     *
     * @param  {Object} app  — objet app du registre des menus Odoo
     * @returns {string}     — ex: "fa fa-users", ou "" si icône image PNG/SVG
     */
    getIconClass(app) {
        // L'app a une image binaire (web_icon PNG/SVG) → pas de classe FA
        if (app.webIconData) {
            return "";
        }
        // L'app a une icône de type classe CSS (ex: "fa fa-users")
        if (app.webIcon && typeof app.webIcon === "string" && app.webIcon.startsWith("fa")) {
            return app.webIcon;
        }
        // Icône par défaut si rien n'est défini
        return "fa fa-th-large";
    },
});
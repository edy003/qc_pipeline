/** @odoo-module **/

import { Component, useState, useRef, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { rpc } from "@web/core/network/rpc";

export class ELearningDashboard extends Component {
    static template = "hrmis_dashboard.ELearningDashboard";
    static props = ["*"];

    setup() {
        const currentYear = new Date().getFullYear();

        this.state = useState({
            filters: {
                department_id: null,
                employee_id: null,
            },
            promotionFilters: {
                year: currentYear,
            },
            departments: [],
            // ↑ sera chargé depuis Odoo
            employees: [],
            // ↑ sera chargé depuis Odoo, filtré par département
            availableYears: [currentYear],
            kpis: {
                courses_joined: { count: 0 },
                certification_attempts: { count: 0 },
                avg_course_completion: { value: 0 },
            },
            promotions: [],
            loading: false,
        });

        this.courseStatusChartRef = useRef("courseStatusChart");
        this.certificateStatusChartRef = useRef("certificateStatusChart");

        onMounted(async () => {
            await this._loadDepartments();
            await this._loadEmployees();
            await this._loadPromotionYears();
            await this._loadKpis();
            await this._loadCharts();
            await this._loadPromotions();
        });
    }

    // ─── Chargement initial ───────────────────────────────────────────────

    async _loadDepartments() {
        try {
            const departments = await rpc("/hrmis/dashboard/departments", {});
            this.state.departments = departments;
        } catch (e) {
            console.error("Erreur chargement départements", e);
        }
    }

    async _loadEmployees(departmentId = null) {
        try {
            const employees = await rpc("/hrmis/dashboard/employees", {
                department_id: departmentId,
            });
            this.state.employees = employees;

            // Si l'employé sélectionné n'est plus dans la liste → reset
            if (
                this.state.filters.employee_id &&
                !employees.find((e) => e.id === this.state.filters.employee_id)
            ) {
                this.state.filters.employee_id = null;
            }
        } catch (e) {
            console.error("Erreur chargement employés", e);
        }
    }

    async _loadKpis() {
        this.state.loading = true;
        try {
            const { department_id, employee_id } = this.state.filters;

            // KPI 1 : Courses Joined (cours distincts)
            const coursesKpi = await rpc(
                "/hrmis/dashboard/kpi/courses_joined",
                {
                    department_id: department_id,
                    employee_id: employee_id,
                }
            );
            this.state.kpis.courses_joined.count = coursesKpi.count;

            const certKpi = await rpc("/hrmis/dashboard/kpi/cert_attempts", 
                {
                    department_id,
                    employee_id,
                });
            this.state.kpis.certification_attempts.count = certKpi.count;
            const avgKpi = await rpc("/hrmis/dashboard/kpi/avg_completion", 
                {
                    department_id,
                    employee_id,
                });
            this.state.kpis.avg_course_completion.value = avgKpi.value;

            // TODO: appels pour les autres KPIs au fur et à mesure
        } catch (e) {
            console.error("Erreur chargement KPIs", e);
        } finally {
            this.state.loading = false;
        }
    }

    async _loadCharts() {
    const { department_id, employee_id } = this.state.filters;

    try {
        const data = await rpc("/hrmis/dashboard/charts/course_status", {
            department_id,
            employee_id,
        });
        this._renderCourseStatusChart(data);
    } catch (e) {
        console.error("Erreur chart statut cours:", e);
    }

    try {
        const certData = await rpc("/hrmis/dashboard/charts/cert_status", {
            department_id,
            employee_id,
        });
        this._renderCertStatusChart(certData);
    } catch (e) {
        console.error("Erreur chart statut certifications:", e);
    }
}

async _loadPromotionYears() {
    try {
        const { department_id, employee_id } = this.state.filters;
        const years = await rpc("/hrmis/dashboard/promotions/years", {
            department_id,
            employee_id,
        });
        this.state.availableYears = years;
        // S'assurer que l'année sélectionnée est toujours valide
        if (!years.includes(this.state.promotionFilters.year)) {
            this.state.promotionFilters.year = years[0] || new Date().getFullYear();
        }
    } catch (e) {
        console.error("Erreur chargement années promotions", e);
    }
}

async _loadPromotions() {
    try {
        const { department_id, employee_id } = this.state.filters;
        const { year } = this.state.promotionFilters;

        const promotions = await rpc("/hrmis/dashboard/promotions", {
            department_id,
            employee_id,
            year,
        });
        this.state.promotions = promotions;
    } catch (e) {
        console.error("Erreur chargement promotions", e);
    }
}


_renderCourseStatusChart(data) {
    const canvas = this.courseStatusChartRef.el;
    if (!canvas || !window.Chart) return;

    if (this._courseStatusChartInstance) {
        this._courseStatusChartInstance.destroy();
    }

    if (!data || !data.data || data.data.every(v => v === 0)) return;

    this._courseStatusChartInstance = new window.Chart(canvas, {
        type: "doughnut",
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: ["#378ADD", "#BA7517", "#1D9E75"],
                borderWidth: 2,
                borderColor: "#ffffff",
                hoverOffset: 6,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "60%",
            plugins: {
                legend: {
                    position: "bottom",
                    labels: { boxWidth: 12, padding: 14, font: { size: 11 } },
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = data.data.reduce((a, b) => a + b, 0) || 1;
                            const pct = ((ctx.parsed / total) * 100).toFixed(1);
                            return ` ${ctx.label} : ${ctx.parsed} cours (${pct}%)`;
                        },
                    },
                },
            },
        },
    });
}

_renderCertStatusChart(data) {
    const canvas = this.certificateStatusChartRef.el;
    if (!canvas || !window.Chart) return;

    if (this._certStatusChartInstance) {
        this._certStatusChartInstance.destroy();
    }

    if (!data || !data.data || data.data.every(v => v === 0)) return;

    this._certStatusChartInstance = new window.Chart(canvas, {
        type: "doughnut",
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: ["#1D9E75", "#E05252","#378ADD"],
                borderWidth: 2,
                borderColor: "#ffffff",
                hoverOffset: 6,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "60%",
            plugins: {
                legend: {
                    position: "bottom",
                    labels: { boxWidth: 12, padding: 14, font: { size: 11 } },
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = data.total || 1;
                            const pct = ((ctx.parsed / total) * 100).toFixed(1);
                            return ` ${ctx.label} : ${ctx.parsed} (${pct}%)`;
                        },
                    },
                },
            },
        },
    });
}


    // ─── Handlers filtres ─────────────────────────────────────────────────

    async onChangeDepartment(ev) {
        const val = ev.target.value ? parseInt(ev.target.value) : null;
        this.state.filters.department_id = val;

        // Filtre en cascade : recharger les employés du département
        await this._loadEmployees(val);
    }

    onChangeEmployee(ev) {
        this.state.filters.employee_id = ev.target.value
            ? parseInt(ev.target.value)
            : null;
    }

    async onChangePromotionYear(ev) {
    this.state.promotionFilters.year = ev.target.value
        ? parseInt(ev.target.value)
        : new Date().getFullYear();
    await this._loadPromotions();
    }

    async onApplyFilters() {
        await this._loadKpis();
        await this._loadCharts();
        await this._loadPromotionYears();   // ← ajoute
        await this._loadPromotions();
    }

    async onResetFilters() {
        this.state.filters.department_id = null;
        this.state.filters.employee_id = null;
        // Recharger tous les employés (sans filtre département)
        await this._loadEmployees(null);
        await this._loadKpis();
        await this._loadCharts();
        await this._loadPromotionYears();   // ← ajoute
        await this._loadPromotions(); 
    }
}

registry.category("actions").add("hrmis_elearning_dashboard", ELearningDashboard);
/** @odoo-module **/

import { Component, useState, useRef, onMounted, onWillUnmount } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

export class LeaveDashboard extends Component {
    static template = "hrmis_dashboard.LeaveDashboard";
    static props = ["*"];

    setup() {
        this.orm = useService("orm");

        // ── État global ──────────────────────────
        this.state = useState({

            // ── Filtres ───────────────────────────
            filters: {
                date_from         : this._getYearStart(),
                date_to           : this._getYearEnd(),
                department_id     : null,
                holiday_status_id : null,
            },

            // ── Données des listes déroulantes ────
            departments  : [],
            leave_types  : [],

            // ── KPIs ──────────────────────────────
            kpis: {
                leaves_in_progress: {
                    count          : 0,
                    employee_count : 0,
                    detail         : [],
                    loading        : true,
                    error          : null,
                },
                pending_approval: {
                    count   : 0,
                    loading : true,
                    error   : null,
                },
                long_leaves: {
                    count   : 0,
                    loading : true,
                    error   : null,
                },
            },

            // ── Alerts ────────────────────────────
            alerts: {
                loading : true,
                rows    : [],
                error   : null,
            },

            // ── Charts (à venir) ──────────────────
            charts: {
                by_type   : [],
                by_month  : [],
                // by_dept   : [],
                approved_vs_refused: [], 
                
            },
        });

        this.typeChartRef    = useRef("typeChart");
        this.trendChartRef   = useRef("trendChart");
        // this.balanceChartRef = useRef("balanceChart");
        this.approvedRefusedChartRef = useRef("approvedRefusedChart");
        this.chartInstances  = {};

        this.COLORS = {
            BLUE  : "#378ADD",
            TEAL  : "#1D9E75",
            AMBER : "#BA7517",
            CORAL : "#D85A30",
            PURPLE: "#7F77DD",
            GREEN : "#639922",
            RED   : "#E24B4A",
            GRAY  : "#888780",
            GRID  : "rgba(136,135,128,0.15)",
        };

        this.MONTHS = ["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];

        onMounted(async () => {
            await this._loadDropdowns();
            await this._fetchAll();
        });

        onWillUnmount(() => { this._destroyCharts(); });
    }

    // ─────────────────────────────────────────────
    // HELPERS DATE
    // ─────────────────────────────────────────────
    _getYearStart() {
        return `${new Date().getFullYear()}-01-01`;
    }

    _getYearEnd() {
        return `${new Date().getFullYear()}-12-31`;
    }

    // ─────────────────────────────────────────────
    // CHARGEMENT DES LISTES DÉROULANTES
    // ─────────────────────────────────────────────
    async _loadDropdowns() {
        try {
            // Départements
            const depts = await this.orm.searchRead(
                "hr.department",
                [["active", "=", true]],
                ["id", "name"],
                { order: "name asc" }
            );
            this.state.departments = depts;

            // Types de congé
            const types = await this.orm.searchRead(
                "hr.leave.type",
                [["active", "=", true]],
                ["id", "name"],
                { order: "name asc" }
            );
            this.state.leave_types = types;

        } catch (e) {
            console.error("Erreur chargement dropdowns:", e);
        }
    }

    // ─────────────────────────────────────────────
    // FETCH GLOBAL (appelle tous les KPIs + charts)
    // ─────────────────────────────────────────────
    async _fetchAll() {
        await this._fetchKpiLeavesInProgress();
        await this._fetchKpiPendingApproval();
        await this._fetchKpiLongLeaves();
        await this._fetchChartByType();
        await this._fetchChartByMonth();
        await this._fetchChartApprovedVsRefused(); 
        // await this._fetchAlerts();
    }

    // ─────────────────────────────────────────────
    // KPI 1 — CONGÉS EN COURS
    // ─────────────────────────────────────────────
    async _fetchKpiLeavesInProgress() {
        this.state.kpis.leaves_in_progress.loading = true;
        this.state.kpis.leaves_in_progress.error   = null;

        try {
            const result = await rpc("/hrmis/leave/dashboard", {
                filters: {
                    date_from         : this.state.filters.date_from,
                    date_to           : this.state.filters.date_to,
                    department_id     : this.state.filters.department_id,
                    holiday_status_id : this.state.filters.holiday_status_id,
                },
            });

            const kpi = result.kpi_leaves_in_progress;
            this.state.kpis.leaves_in_progress.count          = kpi.count;
            this.state.kpis.leaves_in_progress.loading        = false;

        } catch (e) {
            console.error("Erreur KPI congés en cours:", e);
            this.state.kpis.leaves_in_progress.error   = "Erreur de chargement";
            this.state.kpis.leaves_in_progress.loading = false;
        }
    }

    // ─────────────────────────────────────────────
    // KPI 2 — EN ATTENTE D'APPROBATION
    // ─────────────────────────────────────────────
    async _fetchKpiPendingApproval() {
        this.state.kpis.pending_approval.loading = true;
        this.state.kpis.pending_approval.error   = null;

        try {
            const result = await rpc("/hrmis/leave/dashboard", {
                filters: {
                    date_from         : this.state.filters.date_from,
                    date_to           : this.state.filters.date_to,
                    department_id     : this.state.filters.department_id,
                    holiday_status_id : this.state.filters.holiday_status_id,
                },
            });

            const kpi = result.kpi_pending_approval;
            this.state.kpis.pending_approval.count   = kpi.count;
            this.state.kpis.pending_approval.loading = false;

        } catch (e) {
            console.error("Erreur KPI approbation:", e);
            this.state.kpis.pending_approval.error   = "Erreur de chargement";
            this.state.kpis.pending_approval.loading = false;
        }
    }

    // ─────────────────────────────────────────────
    // KPI 3 — CONGÉS VALIDÉS > 30 JOURS
    // ─────────────────────────────────────────────
    async _fetchKpiLongLeaves() {
        this.state.kpis.long_leaves.loading = true;
        this.state.kpis.long_leaves.error   = null;

        try {
            const result = await rpc("/hrmis/leave/dashboard", {
                filters: {
                    date_from         : this.state.filters.date_from,
                    date_to           : this.state.filters.date_to,
                    department_id     : this.state.filters.department_id,
                    holiday_status_id : this.state.filters.holiday_status_id,
                },
            });

            const kpi = result.kpi_long_leaves;
            this.state.kpis.long_leaves.count   = kpi.count;
            this.state.kpis.long_leaves.loading = false;

        } catch (e) {
            console.error("Erreur KPI congés longs:", e);
            this.state.kpis.long_leaves.error   = "Erreur de chargement";
            this.state.kpis.long_leaves.loading = false;
        }
    }

    // ─────────────────────────────────────────────
    // CHART — RÉPARTITION PAR TYPE
    // ─────────────────────────────────────────────
    async _fetchChartByType() {
        try {
            const result = await rpc("/hrmis/leave/chart/by-type", {  // ← route dédiée
                filters: {
                    date_from         : this.state.filters.date_from,
                    date_to           : this.state.filters.date_to,
                    department_id     : this.state.filters.department_id,
                    holiday_status_id : this.state.filters.holiday_status_id,
                },
            });

            this.state.charts.by_type = result;
            this._renderTypeChart();

        } catch (e) {
            console.error("Erreur chart by type:", e);
        }
    }

    async _fetchChartApprovedVsRefused() {
    try {
        const result = await rpc("/hrmis/leave/chart/approved-vs-refused", {
            filters: {
                date_from         : this.state.filters.date_from,
                date_to           : this.state.filters.date_to,
                department_id     : this.state.filters.department_id,
                holiday_status_id : this.state.filters.holiday_status_id,
            },
        });
        this.state.charts.approved_vs_refused = result;
        this._renderApprovedRefusedChart();
    } catch (e) {
        console.error("Erreur chart approved vs refused:", e);
    }
    }

    _renderApprovedRefusedChart() {
    const canvas = this.approvedRefusedChartRef.el;
    if (!canvas || !window.Chart) return;

    if (this.chartInstances.approvedRefusedChart) {
        this.chartInstances.approvedRefusedChart.destroy();
    }

    const data = this.state.charts.approved_vs_refused;
    if (!data || !data.labels || data.labels.length === 0) return;

    this.chartInstances.approvedRefusedChart = new window.Chart(canvas, {
        type: "doughnut",
        data: {
            labels  : data.labels,
            datasets: [{
                data           : data.data,
                backgroundColor: [this.COLORS.TEAL, this.COLORS.CORAL],
                borderWidth    : 2,
                borderColor    : "#ffffff",
                hoverOffset    : 6,
            }],
        },
        options: {
            responsive          : true,
            maintainAspectRatio : false,
            cutout              : "60%",
            plugins: {
                legend: {
                    position: "bottom",
                    labels  : { boxWidth: 12, padding: 14, font: { size: 11 } },
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = data.total || 1;
                            const pct   = ((ctx.parsed / total) * 100).toFixed(1);
                            return ` ${ctx.label} : ${ctx.parsed} (${pct}%)`;
                        },
                    },
                },
            },
        },
    });
    }

    _renderTypeChart() {
        const canvas = this.typeChartRef.el;
        if (!canvas || !window.Chart) return;

        if (this.chartInstances.typeChart) {
            this.chartInstances.typeChart.destroy();
        }

        const data = this.state.charts.by_type;
        if (!data || !data.labels || data.labels.length === 0) return;

        this.chartInstances.typeChart = new window.Chart(canvas, {
            type: 'doughnut',
            data: {
                labels  : data.labels,
                datasets: [{
                    data           : data.data,
                    backgroundColor: [
                        this.COLORS.BLUE,
                        this.COLORS.TEAL,
                        this.COLORS.AMBER,
                        this.COLORS.CORAL,
                        this.COLORS.PURPLE,
                        this.COLORS.GREEN,
                        this.COLORS.RED,
                        this.COLORS.GRAY,
                    ],
                    borderWidth: 2,
                }],
            },
            options: {
                responsive         : true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels  : { boxWidth: 12, padding: 16 },
                    },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => ` ${ctx.label} : ${ctx.parsed} congé(s)`,
                        },
                    },
                },
            },
        });
    }

    // ─────────────────────────────────────────────
    // CHART — ÉVOLUTION MENSUELLE
    // ─────────────────────────────────────────────
    async _fetchChartByMonth() {
        try {
            const result = await rpc("/hrmis/leave/chart/by-month", {
                filters: {
                    date_from         : this.state.filters.date_from,
                    date_to           : this.state.filters.date_to,
                    department_id     : this.state.filters.department_id,
                    holiday_status_id : this.state.filters.holiday_status_id,
                },
            });

            this.state.charts.by_month = result;
            this._renderTrendChart();

        } catch (e) {
            console.error("Erreur chart by month:", e);
        }
    }

    _renderTrendChart() {
        const canvas = this.trendChartRef.el;
        if (!canvas || !window.Chart) return;

        if (this.chartInstances.trendChart) {
            this.chartInstances.trendChart.destroy();
        }

        const data = this.state.charts.by_month;
        if (!data || !data.labels || data.labels.length === 0) return;

        this.chartInstances.trendChart = new window.Chart(canvas, {
            type: 'line',
            data: {
                labels  : data.labels,
                datasets: [{
                    label          : 'Congés validés',
                    data           : data.data,
                    borderColor    : this.COLORS.BLUE,
                    backgroundColor: 'rgba(55, 138, 221, 0.15)',  // ← area
                    borderWidth    : 2,
                    pointRadius    : 4,
                    pointBackgroundColor: this.COLORS.BLUE,
                    fill           : true,   // ← active l'area
                    tension        : 0.4,    // ← courbe lissée
                }],
            },
            options: {
                responsive         : true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels  : { boxWidth: 12, padding: 16 },
                    },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => ` ${ctx.parsed.y} congé(s)`,
                        },
                    },
                },
                scales: {
                    x: {
                        grid: { color: this.COLORS.GRID },
                    },
                    y: {
                        beginAtZero: true,
                        ticks      : { stepSize: 1, precision: 0 },
                        grid       : { color: this.COLORS.GRID },
                    },
                },
            },
        });
    }

    // ─────────────────────────────────────────────
    // GESTION DES FILTRES
    // ─────────────────────────────────────────────
    onChangeDepartment(ev) {
        this.state.filters.department_id = ev.target.value
            ? parseInt(ev.target.value)
            : null;
    }

    onChangeLeaveType(ev) {
        this.state.filters.holiday_status_id = ev.target.value
            ? parseInt(ev.target.value)
            : null;
    }

    onChangeDateFrom(ev) {
        this.state.filters.date_from = ev.target.value || this._getYearStart();
    }

    onChangeDateTo(ev) {
        this.state.filters.date_to = ev.target.value || this._getYearEnd();
    }

    async onApplyFilters() {
        await this._fetchAll();
    }

    async onResetFilters() {
        this.state.filters.date_from         = this._getYearStart();
        this.state.filters.date_to           = this._getYearEnd();
        this.state.filters.department_id     = null;
        this.state.filters.holiday_status_id = null;
        await this._fetchAll();
    }

    // ─────────────────────────────────────────────
    // CHARTS
    // ─────────────────────────────────────────────
    _destroyCharts() {
        Object.values(this.chartInstances).forEach((c) => c && c.destroy());
        this.chartInstances = {};
    }

    _renderCharts() {
        if (!window.Chart) return;
        this._destroyCharts();
        // this._renderTypeChart();
        // this._renderTrendChart();
        // this._renderBalanceChart();
    }
}

registry.category("actions").add("hrmis_leave_dashboard", LeaveDashboard);
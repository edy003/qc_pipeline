/** @odoo-module **/

import { Component, useState, useRef, onMounted, onWillUnmount } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

export class AttendanceDashboard extends Component {
    static template = "hrmis_dashboard.AttendanceDashboard";
    static props = ["*"];

    setup() {
        this.orm = useService("orm");

        this.state = useState({
            departments: [],
            filters: {
                department_id: "",
                date_start: "",
                date_end: "",
            },
            kpis: {
                attendance_rate    : null,
                working_days_done  : 0,
                working_days_total : 0,
                unauthorized_rate  : null,
                unauthorized_days  : 0,
                absence_rate       : null,   // 100 - attendance_rate, calculé côté front
                consecutive_alerts  : 0, 
            },
            periodLabel: "",
            monthlyData: [],  
            alerts: [],
            alertsLoading: false,
        });

        this.combinedChartRef = useRef("combinedChart");
        this.chartInstances   = {};

        this.COLORS = {
            BLUE  : "#378ADD",
            RED   : "#E24B4A",
            AMBER : "#BA7517",
            GRID  : "rgba(136,135,128,0.15)",
        };

        onMounted(async () => {
            await this._loadDepartments();
            this._setDefaultDates();
            // Premier chargement — pas de confirm, juste au montage
            await this._loadAll();
        });

        onWillUnmount(() => {
            this._destroyCharts();
        });
    }

    // ──────────────────────────────────────────────────────────
    //  HANDLERS UI
    // ──────────────────────────────────────────────────────────

    /** Mise à jour des filtres sans déclencher de requête. */
    onChangeFilter(ev) {
        this.state.filters[ev.target.name] = ev.target.value;
    }

    /** Bouton Apply → déclenche le chargement. */
    async onApplyFilters() {
        await this._loadAll();
    }

    /** Bouton Reset → remet les valeurs par défaut et recharge. */
    async onResetFilters() {
        this.state.filters.department_id = "";
        this._setDefaultDates();
        await this._loadAll();
    }

    /** Bouton Contact : ouvre le client mail avec l'adresse de l'agent. */
    onContactEmployee(alert) {
        if (alert.email) {
            window.location.href = `mailto:${alert.email}`;
        }
    }

    // ──────────────────────────────────────────────────────────
    //  CHARGEMENT DES DONNÉES
    // ──────────────────────────────────────────────────────────

    async _loadDepartments() {
        const result = await this.orm.searchRead(
            "hr.department",
            [],
            ["id", "name"],
            { order: "name asc" }
        );
        this.state.departments = result || [];
    }

    /** Lance les 3 appels API en parallèle. */
    async _loadAll() {
        await Promise.all([
            this._loadAttendanceRate(),
            this._loadUnauthorizedRate(),
            this._loadAlerts(),
            this._loadMonthlyTrend(),
        ]);
        this._renderCharts();
    }

    async _loadAttendanceRate() {
        const payload = this._buildPayload();
        const data = await rpc("/hrmis/kpi/attendance-rate", payload);

        this.state.kpis.attendance_rate    = data?.rate            ?? 0.0;
        this.state.kpis.working_days_done  = data?.working_days_done  ?? 0;
        this.state.kpis.working_days_total = data?.working_days_total ?? 0;
        this.state.periodLabel = data?.period_label || this.state.periodLabel;

        // Taux d'absence global (justifiée + non justifiée)
        const att = this.state.kpis.attendance_rate;
        this.state.kpis.absence_rate = att !== null
            ? Math.max(0, parseFloat((100 - att).toFixed(1)))
            : null;
    }

    async _loadMonthlyTrend() {
        const payload = this._buildPayload();
        const data = await rpc("/hrmis/kpi/attendance-monthly", payload);
        this.state.monthlyData = data?.months || [];
    }

    async _loadUnauthorizedRate() {
        const payload = this._buildPayload();
        const data = await rpc("/hrmis/kpi/unauthorized-absence-rate", payload);

        this.state.kpis.unauthorized_rate = data?.rate               ?? 0.0;
        this.state.kpis.unauthorized_days = data?.unauthorized_days   ?? 0;
    }

    // Après — on met à jour le KPI en même temps
    async _loadAlerts() {
        this.state.alertsLoading = true;
        try {
            const payload = {
                ...this._buildPayload(),
                threshold: 3,
            };
            const data = await rpc("/hrmis/kpi/consecutive-absences", payload);
            this.state.alerts = data?.alerts || [];
            this.state.kpis.consecutive_alerts = this.state.alerts.length;  // ← ajouter
        } catch (_) {
            this.state.alerts = [];
            this.state.kpis.consecutive_alerts = 0;  // ← ajouter
        } finally {
            this.state.alertsLoading = false;
        }
    }

    // ──────────────────────────────────────────────────────────
    //  UTILITAIRES
    // ──────────────────────────────────────────────────────────

    _buildPayload() {
        return {
            department_id : this.state.filters.department_id
                ? parseInt(this.state.filters.department_id, 10)
                : false,
            date_start : this.state.filters.date_start || false,
            date_end   : this.state.filters.date_end   || false,
        };
    }

    _setDefaultDates() {
        const year = new Date().getFullYear();
        this.state.filters.date_start = `${year}-01-01`;
        this.state.filters.date_end   = `${year}-12-31`;
    }

    /** Retourne la classe CSS de gravité pour N jours consécutifs. */
    alertSeverity(days) {
        if (days >= 10) return "critical";
        if (days >= 5)  return "warn";
        return "monitor";
    }

    // ──────────────────────────────────────────────────────────
    //  GRAPHIQUE COMBINÉ
    // ──────────────────────────────────────────────────────────

    _destroyCharts() {
        Object.values(this.chartInstances).forEach(c => c && c.destroy());
        this.chartInstances = {};
    }

    _renderCharts() {
        if (!window.Chart) return;
        this._destroyCharts();
        this._renderCombinedChart();
    }

    /**
     * Graphique combiné : ligne Attendance Rate + ligne Unauthorized Absence Rate
     * sur les 12 mois de l'année en cours.
     * Les données mensuelles ne sont pas encore disponibles depuis le backend
     * (nécessiterait une route supplémentaire par mois) — on affiche null
     * pour l'instant, le graphique est prêt à recevoir les données mensuelles.
     */
    _renderCombinedChart() {
        const canvas = this.combinedChartRef.el;
        if (!canvas) return;
 
        const months = this.state.monthlyData;
 
        // Labels dynamiques depuis l'API (ex: "Jan 2026", "Fév 2026"…)
        // Si pas encore chargé, on affiche les 12 mois par défaut
        const labels = months.length
            ? months.map(m => m.label)
            : ["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];
 
        const attData = months.length
            ? months.map(m => m.attendance_rate)   // null = mois futur → pas tracé
            : Array(12).fill(0);
 
        const absData = months.length
            ? months.map(m => m.absence_rate)
            : Array(12).fill(0);
 
        this.chartInstances.combined = new window.Chart(canvas, {
            type: "line",
            data: {
                labels,
                datasets: [
                    {
                        label          : "Attendance Rate (%)",
                        data           : attData,
                        borderColor    : this.COLORS.BLUE,
                        pointBackgroundColor: this.COLORS.BLUE,
                        backgroundColor: "rgba(55,138,221,0.12)",
                        fill           : true,
                        tension        : 0.4,
                        pointRadius    : 4,
                        borderWidth    : 2,
                        spanGaps       : true,   // ← ne relie pas les mois futurs (null)
                        yAxisID        : "y",
                    },
                    {
                        label          : "Absence Rate (%)",
                        data           : absData,
                        borderColor    : this.COLORS.RED,
                        pointBackgroundColor: this.COLORS.RED,
                        backgroundColor: "rgba(226,75,74,0.08)",
                        fill           : true,
                        tension        : 0.4,
                        pointRadius    : 4,
                        borderWidth    : 2,
                        spanGaps       : true,
                        yAxisID        : "y",
                    },
                ],
            },
            options: {
                responsive          : true,
                maintainAspectRatio : false,
                // interaction: {
                //     mode     : "index",
                //     intersect: false,
                // },
                plugins: {
                    // legend: {
                    //     display : true,
                    //     position: "top",
                    //     labels  : {
                    //         boxWidth : 12,
                    //         font     : { size: 11 },
                    //         padding  : 16,
                    //     },
                    // },
                    // REMPLACER
                    legend: {
                        position : "top",
                        labels   : {
                            boxWidth : 12,
                            padding  : 16,
                            font     : { size: 11 },
                        },
                    },
                    // tooltip: {
                    //     callbacks: {
                    //         label: (ctx) => {
                    //             const v = ctx.parsed.y;
                    //             return `${ctx.dataset.label}: ${v !== null ? v + "%" : "—"}`;
                    //         },
                    //     },
                    // },
                    // REMPLACER
                    tooltip: {
                        callbacks: {
                            label: (ctx) => {
                                const v = ctx.parsed.y;
                                return ` ${ctx.dataset.label} : ${v !== null ? v + "%" : "—"}`;
                            },
                        },
                    },
                },
                scales: {
                    x: {
                        grid : { color: this.COLORS.GRID },
                        ticks: { font: { size: 10 }, maxRotation: 0 },
                    },
                    // y: {
                    //     min  : 0,
                    //     max  : 100,
                    //     grid : { color: this.COLORS.GRID },
                    //     ticks: {
                    //         callback: (v) => `${v}%`,
                    //         font    : { size: 10 },
                    //     },
                    // },
                    y: {
                       beginAtZero : true,
                       ticks       : {
                           stepSize : 1,
                           precision: 0,
                           callback : (v) => `${v}%`,
                           font     : { size: 10 },
                       },
                       grid : { color: this.COLORS.GRID },
                   },
                },
            },
        });
    }
}

registry.category("actions").add("hrmis_attendance_dashboard", AttendanceDashboard);
/** @odoo-module **/

import { Component, useState, onWillStart } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { rpc } from "@web/core/network/rpc";

const MONTHS = [
    { value: "",   label: "All Months" },
    { value: "1",  label: "January" },
    { value: "2",  label: "February" },
    { value: "3",  label: "March" },
    { value: "4",  label: "April" },
    { value: "5",  label: "May" },
    { value: "6",  label: "June" },
    { value: "7",  label: "July" },
    { value: "8",  label: "August" },
    { value: "9",  label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" },
];

export class PaymentDashboard extends Component {
    static template = "hrmis_dashboard.PaymentDashboard";
    static props = ["*"];

    setup() {
        const currentYear = new Date().getFullYear();

        this.state = useState({
            // draft filter values (not yet applied)
            draft_department_id: "",
            draft_employee_id:   "",
            draft_year:          String(currentYear),
            draft_month:         "",

            // displayed data
            rows:            [],
            grand_total:     0,
            departments:     [],
            employees:       [],
            currency_symbol: "",
            loading:         true,
            error:           null,
        });

        this.months = MONTHS;

        // Build year list: current year down to 5 years ago
        this.years = [];
        for (let y = currentYear; y >= currentYear - 5; y--) {
            this.years.push(String(y));
        }

        // Initial load with default filters (current year, no other filters)
        onWillStart(() => this._loadData(false));
    }

    // ------------------------------------------------------------------ //
    //  RPC
    // ------------------------------------------------------------------ //
    async _loadData(applyFilters = false) {
        this.state.loading = true;
        this.state.error   = null;
        try {
            const result = await rpc("/hrmis/payment_dashboard/data", {
                department_id: applyFilters ? (this.state.draft_department_id || null) : null,
                employee_id:   applyFilters ? (this.state.draft_employee_id   || null) : null,
                year:          applyFilters
                    ? (this.state.draft_year || String(new Date().getFullYear()))
                    : String(new Date().getFullYear()),
                month:         applyFilters ? (this.state.draft_month || null) : null,
            });

            this.state.rows            = result.rows        || [];
            this.state.grand_total     = result.grand_total || 0;
            this.state.currency_symbol = result.currency_symbol || "";

            // IDs already come as strings from the controller
            this.state.departments = (result.departments || []).map(d => ({
                ...d, id: String(d.id),
            }));
            this.state.employees = (result.employees || []).map(e => ({
                ...e, id: String(e.id),
            }));

        } catch (e) {
            this.state.error = "An error occurred while loading data. Please try again.";
            console.error(e);
        } finally {
            this.state.loading = false;
        }
    }

    // Reload only the employee list when department changes (UX helper)
    async _reloadEmployees(departmentId) {
        try {
            const result = await rpc("/hrmis/payment_dashboard/data", {
                department_id: departmentId || null,
                employee_id:   null,
                year:          this.state.draft_year || null,
                month:         null,
            });
            this.state.employees = (result.employees || []).map(e => ({
                ...e, id: String(e.id),
            }));
        } catch (e) {
            console.error(e);
        }
    }

    // ------------------------------------------------------------------ //
    //  Filter change handlers (draft only — data not reloaded yet)
    // ------------------------------------------------------------------ //
    async onDepartmentChange(ev) {
        this.state.draft_department_id = ev.target.value;
        this.state.draft_employee_id   = ""; // reset employee when dept changes
        await this._reloadEmployees(ev.target.value);
    }

    onEmployeeChange(ev) {
        this.state.draft_employee_id = ev.target.value;
    }

    onYearChange(ev) {
        this.state.draft_year = ev.target.value;
    }

    onMonthChange(ev) {
        this.state.draft_month = ev.target.value;
    }

    // ------------------------------------------------------------------ //
    //  Apply — sends draft filters to the server and reloads data
    // ------------------------------------------------------------------ //
    async onApply() {
        await this._loadData(true);
    }

    // ------------------------------------------------------------------ //
    //  Reset — clears all filters and reloads with defaults
    // ------------------------------------------------------------------ //
    async onReset() {
        const currentYear = new Date().getFullYear();
        this.state.draft_department_id = "";
        this.state.draft_employee_id   = "";
        this.state.draft_year          = String(currentYear);
        this.state.draft_month         = "";
        await this._loadData(false);
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //
    formatCurrency(amount) {
        const symbol = this.state.currency_symbol;
        return (
            Number(amount).toLocaleString("en-US", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            }) + (symbol ? " " + symbol : "")
        );
    }

    get hasRows() {
        return this.state.rows.length > 0;
    }
}

registry.category("actions").add("hrmis_payment_dashboard", PaymentDashboard);
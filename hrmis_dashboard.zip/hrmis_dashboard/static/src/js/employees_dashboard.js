/** @odoo-module **/

import { Component, useState, useRef, onMounted, onWillUnmount } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

export class EmployeesDashboard extends Component {
    static template = "hrmis_dashboard.EmployeesDashboard";
    static props = ["*"];

    setup() {
        this.orm = useService("orm");

        this.state = useState({

            // ── Filtres ─────────────────────────────────────
            filters: {
                department_id    : null,
                grade_id         : null,   // ← corrigé (était "grade")
                contract_type_id : null,   // ← corrigé (était "contract_type")
                date_from        : this._getYearStart(),
                date_to          : this._getYearEnd(),
            },

            // ── Listes déroulantes ──────────────────────────
            departments    : [],
            grades         : [],
            contract_types : [],

            // ── KPIs ────────────────────────────────────────
            kpis: {
                total_employees   : 0,
                active_contracts  : 0,
                near_retirement   : 0,
                vacant_positions  : 0,
            },

            // ── Données graphiques ──────────────────────────
            charts: {
                by_grade                  : [],
                by_contract_type          : [],
                vacant_by_department      : [],
                recruitment_vs_retirement : [],
            },

            loading: false,
        });

        // ── Refs canvas ─────────────────────────────────────
        this.gradeChartRef    = useRef("gradeChart");
        this.contractChartRef = useRef("contractChart");
        this.vacantChartRef = useRef("vacantChart");
        this.trendChartRef    = useRef("trendChart");
        this.chartInstances   = {};

        // ── Palette couleurs ─────────────────────────────────
        this.COLORS = {
            BLUE   : "#378ADD",
            TEAL   : "#1D9E75",
            AMBER  : "#BA7517",
            CORAL  : "#D85A30",
            PURPLE : "#7F77DD",
            GREEN  : "#639922",
            RED    : "#E24B4A",
            GRAY   : "#888780",
            PINK   : "#D4537E",
            GRID   : "rgba(136,135,128,0.15)",
        };

        onMounted(async () => {
            await this._loadDropdowns();
            await this._fetchAll();
        });

        onWillUnmount(() => { this._destroyCharts(); });
    }

    // ─────────────────────────────────────────────
    // HELPERS DATE
    // ─────────────────────────────────────────────
    _getYearStart() {
        return `${new Date().getFullYear()}-01-01`;
    }

    _getYearEnd() {
        return `${new Date().getFullYear()}-12-31`;
    }

   

    

    // ─────────────────────────────────────────────
    // CHARGEMENT LISTES DÉROULANTES
    // ─────────────────────────────────────────────
    async _loadDropdowns() {
        try {
            const result = await rpc("/hrmis/employee/dropdowns", {});
            this.state.departments    = result.departments    || [];
            this.state.grades         = result.grades         || [];
            this.state.contract_types = result.contract_types || [];
        } catch (e) {
            console.error("Error loading dropdowns:", e);
        }
    }

    // ─────────────────────────────────────────────
    // FETCH GLOBAL
    // ─────────────────────────────────────────────
    async _fetchAll() {
        await this._fetchKpis();
        // TODO (étapes suivantes) :
        await this._fetchChartByGrade();
        await this._fetchChartByContractType();
        await this._fetchChartVacantByDepartment();
        await this._fetchChartRecruitmentVsRetirement();
    }

    // ─────────────────────────────────────────────
    // KPIs
    // ─────────────────────────────────────────────
    async _fetchKpis() {
        try {
            const result = await rpc("/hrmis/employee/kpis", {
                filters: {
                    department_id    : this.state.filters.department_id,
                    grade_id         : this.state.filters.grade_id,
                    contract_type_id : this.state.filters.contract_type_id,
                },
            });
            this.state.kpis.total_employees   = result.total_employees   ?? 0;
            this.state.kpis.active_contracts  = result.active_contracts  ?? 0;
            this.state.kpis.near_retirement   = result.near_retirement   ?? 0;
            this.state.kpis.vacant_positions  = result.vacant_positions  ?? 0;
        } catch (e) {
            console.error("Error fetching KPIs:", e);
        }
    }

    // ─────────────────────────────────────────────
    // CHARTS (stubs — prochaines étapes)
    // ─────────────────────────────────────────────
    async _fetchChartByGrade() {
    try {
        const result = await rpc("/hrmis/employee/chart/by-grade", {
            filters: {
                department_id    : this.state.filters.department_id,
                grade_id         : this.state.filters.grade_id, 
                contract_type_id : this.state.filters.contract_type_id,
            },
        });
        this.state.charts.by_grade = result;
        this._renderGradeChart();
    } catch (e) {
        console.error("Error fetching chart by grade:", e);
    }
}
 

    async _fetchChartByContractType() {
    try {
        const result = await rpc("/hrmis/employee/chart/by-contract-type", {
            filters: {
                department_id    : this.state.filters.department_id,
                grade_id         : this.state.filters.grade_id,         // ✅
                contract_type_id : this.state.filters.contract_type_id, // ✅
            },
        });
        this.state.charts.by_contract_type = result;
        this._renderContractChart();
    } catch (e) {
        console.error("Error fetching chart by contract type:", e);
    }
   }
    

   async _fetchChartVacantByDepartment() {
    try {
        const result = await rpc("/hrmis/employee/chart/vacant-by-department", {
            filters: {
                department_id    : this.state.filters.department_id,
                grade_id         : this.state.filters.grade_id,
                contract_type_id : this.state.filters.contract_type_id,
            },
        });
        this.state.charts.vacant_by_department = result;
        this._renderVacantChart();
    } catch (e) {
        console.error("Error fetching vacant by department:", e);
    }
    }
    
    async _fetchChartRecruitmentVsRetirement() {
    try {
        const result = await rpc("/hrmis/employee/chart/active-vs-retirement", {
            filters: {
                department_id    : this.state.filters.department_id,
                grade_id         : this.state.filters.grade_id,
                contract_type_id : this.state.filters.contract_type_id,
                date_from        : this.state.filters.date_from,
                date_to          : this.state.filters.date_to,
            },
        });
        this.state.charts.recruitment_vs_retirement = result;
        this._renderTrendChart();
    } catch (e) {
        console.error("Error fetching active vs retirement chart:", e);
    }
}

    _renderGradeChart() {
    const canvas = this.gradeChartRef.el;
    if (!canvas || !window.Chart) return;
 
    // Détruire l'instance précédente si elle existe
    if (this.chartInstances.gradeChart) {
        this.chartInstances.gradeChart.destroy();
    }
 
    const data = this.state.charts.by_grade;
    if (!data || !data.labels || data.labels.length === 0) return;
 
    this.chartInstances.gradeChart = new window.Chart(canvas, {
        type: "doughnut",
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: [
                    this.COLORS.BLUE,
                    this.COLORS.TEAL,
                    this.COLORS.AMBER,
                    this.COLORS.CORAL,
                    this.COLORS.PURPLE,
                    this.COLORS.GREEN,
                    this.COLORS.RED,
                    this.COLORS.GRAY,
                    this.COLORS.PINK,
                ],
                borderWidth: 2,
                borderColor: "#ffffff",
                hoverOffset: 6,
            }],
        },
        options: {
            responsive         : true,
            maintainAspectRatio: false,
            cutout             : "60%",   // ← doughnut, pas pie plein
            plugins: {
                legend: {
                    position : "bottom",
                    labels   : {
                        boxWidth  : 12,
                        padding   : 14,
                        font      : { size: 11 },
                    },
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = data.total || 1;
                            const pct   = ((ctx.parsed / total) * 100).toFixed(1);
                            return ` ${ctx.label} : ${ctx.parsed} (${pct}%)`;
                        },
                    },
                },
            },
        },
    });
}
    _renderContractChart() {
    const canvas = this.contractChartRef.el;
    if (!canvas || !window.Chart) return;

    if (this.chartInstances.contractChart) {
        this.chartInstances.contractChart.destroy();
    }

    const data = this.state.charts.by_contract_type;
    if (!data || !data.labels || data.labels.length === 0) return;

    this.chartInstances.contractChart = new window.Chart(canvas, {
        type: "doughnut",
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: [
                    this.COLORS.TEAL,
                    this.COLORS.BLUE,
                    this.COLORS.AMBER,
                    this.COLORS.CORAL,
                    this.COLORS.PURPLE,
                    this.COLORS.GREEN,
                    this.COLORS.RED,
                    this.COLORS.GRAY,
                    this.COLORS.PINK,
                ],
                borderWidth: 2,
                borderColor: "#ffffff",
                hoverOffset: 6,
            }],
        },
        options: {
            responsive          : true,
            maintainAspectRatio : false,
            cutout              : "60%",
            plugins: {
                legend: {
                    position : "bottom",
                    labels   : {
                        boxWidth : 12,
                        padding  : 14,
                        font     : { size: 11 },
                    },
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = data.total || 1;
                            const pct   = ((ctx.parsed / total) * 100).toFixed(1);
                            return ` ${ctx.label} : ${ctx.parsed} (${pct}%)`;
                        },
                    },
                },
            },
        },
    });
   }
   

   _renderVacantChart() {
    const canvas = this.vacantChartRef.el;
    if (!canvas || !window.Chart) return;

    if (this.chartInstances.vacantChart) {
        this.chartInstances.vacantChart.destroy();
    }

    const data = this.state.charts.vacant_by_department;
    if (!data || !data.labels || data.labels.length === 0) return;

    this.chartInstances.vacantChart = new window.Chart(canvas, {
        type: "doughnut",
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: [
                    this.COLORS.BLUE,
                    this.COLORS.RED,
                    this.COLORS.AMBER,
                    this.COLORS.PURPLE,   
                ],
                borderWidth     : 2,
                borderColor     : "#ffffff",
                hoverOffset     : 6,
            }],
        },
        options: {
            responsive          : true,
            maintainAspectRatio : false,
            cutout              : "60%",
            plugins: {
                legend: {
                    position : "bottom",
                    labels   : {
                        boxWidth : 12,
                        padding  : 14,
                        font     : { size: 11 },
                    },
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = data.total || 1;
                            const pct   = ((ctx.parsed / total) * 100).toFixed(1);
                            return ` ${ctx.label} : ${ctx.parsed} (${pct}%)`;
                        },
                    },
                },
            },
        },
    });
    }
    
    _renderTrendChart() {
    const canvas = this.trendChartRef.el;
    if (!canvas || !window.Chart) return;

    if (this.chartInstances.trendChart) {
        this.chartInstances.trendChart.destroy();
    }

    const data = this.state.charts.recruitment_vs_retirement;
    if (!data || !data.labels || data.labels.length === 0) return;

    const activeData     = data.active_data;
    const retirementData = data.retirement_data;

    this.chartInstances.trendChart = new window.Chart(canvas, {
        type: "line",
        data: {
            labels: data.labels,
            datasets: [
                {
                    label           : "Active Contracts",
                    data            : activeData,
                    borderColor     : this.COLORS.BLUE,
                    backgroundColor : "rgba(55,138,221,0.10)",
                    pointBackgroundColor: this.COLORS.BLUE,
                    borderWidth     : 2,
                    pointRadius     : 4,
                    tension         : 0.4,
                    fill            : true,
                },
                {
                    label           : "Retirements",
                    data            : retirementData,
                    pointBackgroundColor: this.COLORS.AMBER,
                    borderColor     : this.COLORS.AMBER,
                    backgroundColor : "rgba(186,117,23,0.10)",
                    borderWidth     : 2,
                    pointRadius     : 4,
                    tension         : 0.4,
                    fill            : true,
                },
            ],
        },
        options: {
            responsive          : true,
            maintainAspectRatio : false,
            // interaction: {
            //     mode     : "index",
            //     intersect: false,
            // },
            scales: {
                x: {
                    grid : { color: this.COLORS.GRID },
                    ticks: { font: { size: 11 } },
                },
                // y: {
                //     type        : "linear",
                //     beginAtZero : true,
                //     grid        : { color: this.COLORS.GRID },
                //     ticks       : {
                //         display : true,
                //         font    : { size: 11 },
                //     },
                // },
                y: {
                    beginAtZero : true,
                    ticks       : { stepSize: 1, precision: 0 },
                    grid        : { color: this.COLORS.GRID },
                },
            },
            plugins: {
                // legend: {
                //     display  : true,
                //     position : "top",
                //     align    : "end",
                //     labels   : {
                //         boxWidth     : 12,
                //         padding      : 16,
                //         font         : { size: 12 },
                //         usePointStyle: true,
                //         pointStyle   : "circle",
                //     },
                // },
                // REMPLACER
                legend: {
                    position : "top",
                    labels   : {
                        boxWidth : 12,
                        padding  : 16,
                        font     : { size: 12 },
                    },
                },
                // REMPLACER
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const real = ctx.datasetIndex === 0
                                ? data.active_data[ctx.dataIndex]
                                : data.retirement_data[ctx.dataIndex];
                            return ` ${ctx.dataset.label} : ${real}`;
                        },
                    },
                },
            },
        },
    });
    console.log("4. chart créé:", this.chartInstances.trendChart);
}
    // ─────────────────────────────────────────────
    // GESTION DES FILTRES
    // ─────────────────────────────────────────────
    onChangeDepartment(ev) {
        this.state.filters.department_id = ev.target.value
            ? parseInt(ev.target.value) : null;
    }

    onChangeGrade(ev) {
        // ← corrigé : écrit sur grade_id (entier), pas "grade" (string)
        this.state.filters.grade_id = ev.target.value
            ? parseInt(ev.target.value) : null;
    }

    onChangeContractType(ev) {
        // ← corrigé : écrit sur contract_type_id (entier), pas "contract_type" (string)
        this.state.filters.contract_type_id = ev.target.value
            ? parseInt(ev.target.value) : null;
    }

    onChangeDateFrom(ev) {
        this.state.filters.date_from = ev.target.value || this._getYearStart();
    }

    onChangeDateTo(ev) {
        this.state.filters.date_to = ev.target.value || this._getYearEnd();
    }

    async onApplyFilters() {
        await this._fetchAll();
    }

    onResetTrendFilters() {
    this.state.filters.date_from = this._getYearStart();
    this.state.filters.date_to   = this._getYearEnd();
    this._fetchChartRecruitmentVsRetirement();
    }

    async onResetFilters() {
        this.state.filters.department_id    = null;
        this.state.filters.grade_id         = null;
        this.state.filters.contract_type_id = null;
        this.state.filters.date_from        = this._getYearStart();
        this.state.filters.date_to          = this._getYearEnd();
        await this._fetchAll();
    }

    // ─────────────────────────────────────────────
    // UTILITAIRES GRAPHIQUES
    // ─────────────────────────────────────────────
    _destroyCharts() {
        Object.values(this.chartInstances).forEach(c => c && c.destroy());
        this.chartInstances = {};
    }
}

registry.category("actions").add("hrmis_employees_dashboard", EmployeesDashboard);
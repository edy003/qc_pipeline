# -*- coding: utf-8 -*-
{
    'name': 'HRMIS Dashboard',
    'version': '18.0.1.0.0',
    'category': 'Human Resources',
    'summary': 'HRMIS Dashboard with Employees, Leaves, Attendance and Alerts',
    
    'description': """
        HRMIS Dashboard
        =================
        Modern HR dashboard with multiple views:

        - Employees analytics
        - Leave management dashboard
        - Attendance tracking
        - HR alerts & notifications
    """,
    'depends': [
        'base',
        'web',
        'hr',
        'hr_contract',
        'hr_attendance',
        'hr_holidays',
        'theme_diwy',
        'website',
    ],
    "web_icon": "hrmis_dashboard/static/description/icon.png",
    'data': [
        # 'views/assets.xml',
        'views/hrmis_action.xml',  
        'views/hrmis_menu.xml',           
    ],

    'assets': {
        'web.assets_backend': [
            'hrmis_dashboard/static/src/js/home_menu_patch.js',
            'hrmis_dashboard/static/src/lib/chart.js',
            'hrmis_dashboard/static/src/js/employees_dashboard.js',
            'hrmis_dashboard/static/src/css/employees.css',
            'hrmis_dashboard/static/src/css/attendance_dashboard.css',
            'hrmis_dashboard/static/src/css/leave_dashboard.css',
            'hrmis_dashboard/static/src/css/elearning_dashboard.css',
            'hrmis_dashboard/static/src/css/payment_dashboard.css',
            'hrmis_dashboard/static/src/js/attendance_dashboard.js',
            'hrmis_dashboard/static/src/js/leave_dashboard.js',
            'hrmis_dashboard/static/src/js/elearning_dashboard.js',
            'hrmis_dashboard/static/src/js/payment_dashboard.js',
            'hrmis_dashboard/static/src/xml/employees.xml',
            'hrmis_dashboard/static/src/xml/attendance_dashboard.xml',
            'hrmis_dashboard/static/src/xml/leave_dashboard.xml',
            'hrmis_dashboard/static/src/xml/elearning_dashboard.xml',
            'hrmis_dashboard/static/src/xml/payment_dashboard.xml',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
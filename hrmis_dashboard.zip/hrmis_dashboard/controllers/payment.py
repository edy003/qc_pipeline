# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
from datetime import date
import calendar


class PaymentDashboardController(http.Controller):

    @http.route('/hrmis/payment_dashboard/data', type='json', auth='user')
    def get_dashboard_data(self, department_id=None, employee_id=None,
                           year=None, month=None):
        """
        Returns NET payslip lines for the payment dashboard.

        Why ORM instead of raw SQL for name fields?
        --------------------------------------------
        hr_salary_rule.name  and  hr_department.name  are both declared with
        translate=True in Odoo.  For translatable fields Odoo does NOT store
        the value in the column itself — it stores it in ir_translation (v15-)
        or via the jsonb translations column (v16+).  A raw SQL JOIN on
        `sr.name` or `dep.name` therefore returns NULL when no untranslated
        fallback exists.  Using the ORM resolves the correct value for the
        current user language automatically.

        hr.payslip.line  uses  _inherit = 'hr.salary.rule'  (not _inherits).
        This means every payslip line IS also a salary.rule record sharing the
        same id in hr_salary_rule.  The field `salary_rule_id` on the line
        points to the *template* rule.  We read `line.salary_rule_id.name`
        (template name) which is what appears on the payslip form.
        """
        current_year = date.today().year
        year = int(year) if year else current_year

        # ── 1. Payslip domain (validated payslips only) ──────────────────────
        slip_domain = [('state', '=', 'done')]

        if month:
            month = int(month)
            last_day = calendar.monthrange(year, month)[1]
            slip_domain += [
                ('date_from', '>=', date(year, month, 1)),
                ('date_to',   '<=', date(year, month, last_day)),
            ]
        else:
            slip_domain += [
                ('date_from', '>=', date(year, 1, 1)),
                ('date_to',   '<=', date(year, 12, 31)),
            ]

        if employee_id:
            slip_domain.append(('employee_id', '=', int(employee_id)))
        elif department_id:
            slip_domain.append(
                ('employee_id.department_id', '=', int(department_id)))

        payslips = request.env['hr.payslip'].search(slip_domain)

        rows = []
        currency_symbol = ''

        if payslips:
            # ── Step 1: raw SQL to get IDs and numeric values ────────────────
            # We only pull NON-translatable columns from SQL (ids, numbers,
            # dates, codes).  Translatable text (name fields) are read via ORM.
            request.env.cr.execute("""
                SELECT
                    pl.id                            AS line_id,
                    pl.total                         AS total,
                    sr.code                          AS salary_rule_code,
                    pl.employee_id                   AS employee_id,
                    pl.salary_rule_id                AS salary_rule_id,
                    emp.department_id                AS department_id,
                    ps.number                        AS payslip_reference,
                    TO_CHAR(ps.date_from, 'MM/YYYY') AS payslip_period,
                    cur.symbol                       AS currency_symbol
                FROM
                    hr_payslip_line   pl
                    JOIN hr_payslip     ps   ON ps.id   = pl.slip_id
                    JOIN hr_salary_rule sr   ON sr.id   = pl.salary_rule_id
                    JOIN hr_employee    emp  ON emp.id  = pl.employee_id
                    LEFT JOIN res_company   comp ON comp.id = ps.company_id
                    LEFT JOIN res_currency  cur  ON cur.id  = comp.currency_id
                WHERE
                    pl.slip_id = ANY(%s)
                    AND UPPER(sr.code) = 'NET'
                ORDER BY
                    emp.id, ps.date_from
            """, (list(payslips.ids),))

            sql_rows = request.env.cr.dictfetchall()

            if sql_rows:
                # ── Step 2: batch-load translatable names via ORM ─────────────
                employee_ids    = list({r['employee_id']    for r in sql_rows if r['employee_id']})
                department_ids  = list({r['department_id']  for r in sql_rows if r['department_id']})
                salary_rule_ids = list({r['salary_rule_id'] for r in sql_rows if r['salary_rule_id']})

                # ORM resolves translated fields for the current user language
                employees_map   = {
                    e.id: e.name
                    for e in request.env['hr.employee'].browse(employee_ids)
                }
                departments_map = {
                    d.id: d.name
                    for d in request.env['hr.department'].browse(department_ids)
                }
                rules_map = {
                    r.id: r.name
                    for r in request.env['hr.salary.rule'].browse(salary_rule_ids)
                }

                # ── Step 3: build rows combining SQL values + ORM names ───────
                for r in sql_rows:
                    sym = r['currency_symbol'] or ''
                    if not currency_symbol and sym:
                        currency_symbol = sym

                    rows.append({
                        'department':        departments_map.get(r['department_id'], '—'),
                        'employee_name':     employees_map.get(r['employee_id'],    '—'),
                        'payslip_reference': r['payslip_reference'] or '—',
                        'salary_rule_name':  rules_map.get(r['salary_rule_id'],    '—'),
                        'salary_rule_code':  r['salary_rule_code'] or '',
                        'total':             float(r['total'] or 0.0),
                        'payslip_period':    r['payslip_period']   or '',
                        'currency_symbol':   sym,
                    })

        # ── 2. Filter lists for the selects ──────────────────────────────────
        departments = [
            {'id': str(d.id), 'name': d.name}
            for d in request.env['hr.department'].search([], order='name')
        ]

        emp_domain = []
        if department_id:
            emp_domain = [('department_id', '=', int(department_id))]
        employees = [
            {'id': str(e.id), 'name': e.name}
            for e in request.env['hr.employee'].search(emp_domain, order='name')
        ]

        return {
            'rows':            rows,
            'grand_total':     sum(r['total'] for r in rows),
            'currency_symbol': currency_symbol,
            'departments':     departments,
            'employees':       employees,
            'current_year':    current_year,
        }
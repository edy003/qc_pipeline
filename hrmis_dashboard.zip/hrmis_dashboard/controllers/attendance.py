# -*- coding: utf-8 -*-
"""
HRMIS — Contrôleur KPI 1 : Taux de présence effectif
Fichier  : controllers/attendance.py
Route    : POST /hrmis/kpi/attendance-rate

═══════════════════════════════════════════════════════════════════════
CORRECTIONS ODOO 18
═══════════════════════════════════════════════════════════════════════

ERREUR CORRIGÉE :
    ValueError: Invalid aggregate method 'day' for 'check_in:day'.

    Odoo 18 a supprimé le support de la syntaxe field:day dans read_group.
    On remplace par une requête SQL brute avec DATE(check_in) qui fonctionne
    sur toutes les versions d'Odoo 16, 17, 18.

═══════════════════════════════════════════════════════════════════════
RÈGLES MÉTIER
═══════════════════════════════════════════════════════════════════════

1. DATE DE DÉBUT PAR AGENT = max(date_start_filtre, date_début_contrat)
   → Un agent recruté le 1er mars 2026 n'entre pas dans le dénominateur
     pour janvier et février 2026. Sinon son taux est artificiellement bas
     et tire le taux global vers le bas.

2. JOURS EXCLUS DU DÉNOMINATEUR (jours non travaillés)
   - Week-ends (selon le calendrier contractuel de l'agent)
   - Congés validés (hr.leave, state = 'validate')
   - Jours fériés du calendrier Odoo (resource.calendar.leaves)
   - Jours fériés légaux Odoo 18 (hr.leave.mandatory.day si dispo)

3. FORMULE
   % Pointage = Σ(jours pointés par agent) / Σ(jours attendus par agent) × 100

   Exemple :
     Agent A : contrat depuis le 01/01, 60 jours attendus, 55 pointés
     Agent B : contrat depuis le 01/03, 22 jours attendus, 18 pointés
     Résultat : (55+18) / (60+22) = 73/82 = 89.0%
     → Agent B ne biaise PAS les 2 premiers mois
"""

from odoo import http
from odoo.http import request
from datetime import date, timedelta
import calendar as cal_mod


class AttendanceKpiRateController(http.Controller):

    # ================================================================
    #  ROUTE PRINCIPALE
    # ================================================================

    @http.route(
        "/hrmis/kpi/attendance-rate",
        type="json",
        auth="user",
        methods=["POST"],
        csrf=True,
    )
    def get_kpi_attendance_rate(self, **kwargs):
        date_start    = kwargs.get("date_start")
        date_end      = kwargs.get("date_end")
        department_id = kwargs.get("department_id")

        # 1. Résolution des bornes de la période d'affichage
        d_start, d_end = self._resolve_dates(date_start, date_end)

        # 2. Le calcul ne dépasse jamais aujourd'hui (pas de jours futurs)
        calc_end = min(d_end, date.today())

        if d_start > calc_end:
            return self._empty(d_start, d_end, calc_end)

        # 3. Agents actifs avec contrat ouvert, filtrés par ministère
        employees = self._get_active_employees(department_id)
        if not employees:
            return self._empty(d_start, d_end, calc_end)

        # 4. Date de début de contrat par agent  ← CORRECTION BIAIS
        #    employee_id → date la plus ancienne parmi ses contrats ouverts
        contract_start_by_emp = self._get_contract_start_dates(
            employees.ids, d_start
        )

        # 5. Chargement des données en 2 requêtes SQL
        pointed_days = self._fetch_pointed_days(
            employees.ids, d_start, calc_end
        )
        leave_days = self._fetch_leave_days(
            employees.ids, d_start, calc_end
        )
        off_days = self._fetch_off_days(employees, d_start, calc_end)

        # 6. Calcul jours-agents
        total_exp, total_ptr = self._compute_totals(
            employees,
            d_start,
            calc_end,
            contract_start_by_emp,
            pointed_days,
            leave_days,
            off_days,
        )

        if total_exp == 0:
            return self._empty(d_start, d_end, calc_end)

        return {
            "rate"               : round((total_ptr / total_exp) * 100, 1),
            "working_days_done"  : total_ptr,
            "working_days_total" : total_exp,
            "period_label"       : self._format_period(d_start, d_end),
            "date_start"         : d_start.isoformat(),
            "date_end"           : d_end.isoformat(),
            "calculation_end"    : calc_end.isoformat(),
            "department_id"      : int(department_id) if department_id else False,
        }

    # ================================================================
    #  RÉSOLUTION DES DATES
    # ================================================================

    def _resolve_dates(self, date_start, date_end):
        today = date.today()
        d_start = (
            date.fromisoformat(date_start)
            if date_start
            else date(today.year, 1, 1)      # 1er janvier année en cours
        )
        d_end = (
            date.fromisoformat(date_end)
            if date_end
            else date(today.year, 12, 31)    # 31 décembre année en cours
        )
        if d_start > d_end:
            d_start, d_end = d_end, d_start
        return d_start, d_end

    # ================================================================
    #  AGENTS ACTIFS AVEC CONTRAT OUVERT
    # ================================================================

    def _get_active_employees(self, department_id=None):
        domain = [
            ("active", "=", True),
            ("contract_ids.state", "=", "open"),
        ]
        if department_id:
            domain.append(("department_id", "=", int(department_id)))
        return request.env["hr.employee"].search(domain)

    # ================================================================
    #  DATE DE DÉBUT DE CONTRAT PAR AGENT  ← NOUVELLE MÉTHODE
    # ================================================================

    def _get_contract_start_dates(self, employee_ids, d_start):
        """
        Pour chaque agent, retourne la date à partir de laquelle
        il doit être compté dans le dénominateur :

            effective_start = max(d_start_filtre, date_debut_contrat)

        Si un agent a plusieurs contrats ouverts (rare mais possible),
        on prend le plus ancien — il était actif depuis le plus longtemps.

        On utilise du SQL brut pour un GROUP BY efficace :
            SELECT employee_id, MIN(date_start) FROM hr_contract
            WHERE employee_id IN (...) AND state = 'open'
            GROUP BY employee_id

        Retourne
        --------
        dict { employee_id (int) : effective_start (date) }
        """
        if not employee_ids:
            return {}

        # Requête SQL directe — compatible Odoo 16, 17, 18
        request.env.cr.execute(
            """
            SELECT employee_id, MIN(date_start) AS contract_start
            FROM   hr_contract
            WHERE  employee_id = ANY(%s)
              AND  state = 'open'
              AND  date_start IS NOT NULL
            GROUP  BY employee_id
            """,
            (list(employee_ids),),
        )
        rows = request.env.cr.fetchall()

        result = {}
        for emp_id, contract_start in rows:
            if contract_start is None:
                # Pas de date de début → on utilise d_start du filtre
                result[emp_id] = d_start
            else:
                # effective_start = max(filtre, date contrat)
                # → si contrat commence avant le filtre, on part du filtre
                # → si contrat commence après le filtre, on part du contrat
                result[emp_id] = max(d_start, contract_start)

        # Agents sans ligne dans hr_contract (ne devrait pas arriver
        # vu le filtre sur contract_ids.state, mais sécurité)
        for emp_id in employee_ids:
            if emp_id not in result:
                result[emp_id] = d_start

        return result

    # ================================================================
    #  REQUÊTE 1 — POINTAGES  (SQL brut — fix Odoo 18)
    # ================================================================

    def _fetch_pointed_days(self, employee_ids, d_start, d_end):
        """
        Retourne un set de (employee_id, date) représentant chaque
        combinaison agent/jour pour laquelle au moins un check-in existe.

        CORRECTION ODOO 18 :
            read_group avec groupby "check_in:day" lève une ValueError
            dans Odoo 18 car la syntaxe field:day a été supprimée.

            On remplace par du SQL brut avec DATE(check_in AT TIME ZONE 'UTC')
            qui fonctionne sur toutes les versions.

        GROUP BY employee_id, DATE(check_in) → une ligne par (agent, jour)
        même si l'agent a pointé plusieurs fois dans la journée.
        """
        if not employee_ids:
            return set()

        request.env.cr.execute(
            """
            SELECT employee_id,
                   DATE(check_in AT TIME ZONE 'UTC') AS check_date
            FROM   hr_attendance
            WHERE  employee_id = ANY(%s)
              AND  check_in >= %s
              AND  check_in <= %s
            GROUP  BY employee_id, DATE(check_in AT TIME ZONE 'UTC')
            """,
            (
                list(employee_ids),
                f"{d_start} 00:00:00",
                f"{d_end} 23:59:59",
            ),
        )
        rows = request.env.cr.fetchall()
        return {(emp_id, check_date) for emp_id, check_date in rows}

    # ================================================================
    #  REQUÊTE 2 — CONGÉS VALIDÉS
    # ================================================================

    def _fetch_leave_days(self, employee_ids, d_start, d_end):
        """
        Retourne un set de (employee_id, date) pour chaque jour
        couvert par un congé validé (hr.leave, state = 'validate').

        Condition de chevauchement avec [d_start, d_end] :
            date_from <= d_end  ET  date_to >= d_start
        """
        if not employee_ids:
            return set()

        leaves = request.env["hr.leave"].search([
            ("employee_id", "in", list(employee_ids)),
            ("state",       "=",  "validate"),
            ("date_from",   "<=", f"{d_end} 23:59:59"),
            ("date_to",     ">=", f"{d_start} 00:00:00"),
        ])

        leave_days = set()
        for leave in leaves:
            lv_start = max(leave.date_from.date(), d_start)
            lv_end   = min(leave.date_to.date(),   d_end)
            cursor   = lv_start
            while cursor <= lv_end:
                leave_days.add((leave.employee_id.id, cursor))
                cursor += timedelta(days=1)

        return leave_days

    # ================================================================
    #  REQUÊTE 3 — JOURS FÉRIÉS ET FERMETURES
    # ================================================================

    def _fetch_off_days(self, employees, d_start, d_end):
        """
        Retourne un dict { employee_id: set(date) } contenant
        tous les jours non travaillés hors week-end :
            - Fermetures du calendrier de travail (resource.calendar.leaves)
            - Jours fériés légaux (hr.leave.mandatory.day — Odoo 16+)

        Chaque source est tentée dans un try/except indépendant pour
        éviter qu'une source absente plante l'ensemble du calcul.
        """
        off_days     = {emp.id: set() for emp in employees}
        all_emp_ids  = {emp.id for emp in employees}

        # Mapping calendrier → liste d'employee_ids pour ce calendrier
        cal_to_emps  = {}
        dept_to_emps = {}
        for emp in employees:
            if emp.resource_calendar_id:
                cal_to_emps.setdefault(
                    emp.resource_calendar_id.id, []
                ).append(emp.id)
            if emp.department_id:
                dept_to_emps.setdefault(
                    emp.department_id.id, []
                ).append(emp.id)

        # ── Source 1 : fermetures du calendrier de travail ───────────
        try:
            cal_leaves = request.env["resource.calendar.leaves"].search([
                ("calendar_id", "in", list(cal_to_emps.keys())),
                ("date_from",   "<=", f"{d_end} 23:59:59"),
                ("date_to",     ">=", f"{d_start} 00:00:00"),
                ("resource_id", "=",  False),   # False = s'applique à tout le calendrier
            ])
            for cl in cal_leaves:
                emp_ids = cal_to_emps.get(cl.calendar_id.id, [])
                cl_start = max(cl.date_from.date(), d_start)
                cl_end   = min(cl.date_to.date(),   d_end)
                cursor   = cl_start
                while cursor <= cl_end:
                    for eid in emp_ids:
                        off_days[eid].add(cursor)
                    cursor += timedelta(days=1)
        except Exception:
            pass

        # ── Source 2 : jours fériés légaux (Odoo 18 = hr.leave.mandatory.day) ─
        try:
            mandatory_leaves = request.env["hr.leave.mandatory.day"].search([
                ("start_date", "<=", str(d_end)),
                ("end_date",   ">=", str(d_start)),
            ])
            for ml in mandatory_leaves:
                ml_start = max(
                    date.fromisoformat(str(ml.start_date)[:10]), d_start
                )
                ml_end = min(
                    date.fromisoformat(str(ml.end_date)[:10]), d_end
                )
                # Si le jour férié est restreint à certains départements
                if ml.department_ids:
                    concerned = set()
                    for dept in ml.department_ids:
                        concerned.update(dept_to_emps.get(dept.id, []))
                else:
                    concerned = all_emp_ids

                cursor = ml_start
                while cursor <= ml_end:
                    for eid in concerned:
                        off_days[eid].add(cursor)
                    cursor += timedelta(days=1)
        except Exception:
            pass

        return off_days

    # ================================================================
    #  CALCUL JOURS-AGENTS  ← AVEC DATE CONTRAT PAR AGENT
    # ================================================================

    def _compute_totals(
        self,
        employees,
        d_start,
        d_end,
        contract_start_by_emp,
        pointed_days,
        leave_days,
        off_days,
    ):
        """
        Pour chaque agent, on ne commence à compter que depuis
        la date effective de son contrat :

            emp_start = contract_start_by_emp[emp.id]
                      = max(d_start_filtre, date_début_contrat)

        Exemple :
            Filtre : 01/01/2026 → 31/12/2026
            Agent A : contrat depuis le 01/01/2026 → emp_start = 01/01
            Agent B : contrat depuis le 01/03/2026 → emp_start = 01/03
              → Agent B n'a AUCUN jour attendu en janvier et février
              → son recrutement tardif ne baisse pas le taux de jan-fév

        Pour chaque jour ouvrable dans [emp_start, d_end] :
            - Si jour férié / fermeture  → exclu du dénominateur
            - Si congé validé            → exclu du dénominateur
            - Sinon                      → attendu  (+1 dénominateur)
                - Si check-in existant   → pointé   (+1 numérateur)
        """
        total_exp = 0
        total_ptr = 0

        for emp in employees:
            # Date de début effective pour cet agent
            emp_start = contract_start_by_emp.get(emp.id, d_start)

            # Si le contrat commence après la fin de la période, cet agent
            # ne contribue pas du tout (pas encore recruté sur la période)
            if emp_start > d_end:
                continue

            emp_off      = off_days.get(emp.id, set())
            working_days = self._get_working_days(emp, emp_start, d_end)

            for day in working_days:
                # Jour férié ou fermeture calendrier → pas attendu
                if day in emp_off:
                    continue
                # Congé validé → pas attendu
                if (emp.id, day) in leave_days:
                    continue

                # Jour attendu
                total_exp += 1

                # L'agent a pointé ce jour
                if (emp.id, day) in pointed_days:
                    total_ptr += 1

        return total_exp, total_ptr

    # ================================================================
    #  JOURS OUVRABLES PAR AGENT (calendrier contractuel)
    # ================================================================

    def _get_working_days(self, employee, d_start, d_end):
        """
        Retourne la liste des jours ouvrables selon le calendrier
        de travail de l'agent (resource.calendar_id).

        resource.calendar.attendance.dayofweek :
            "0" = Lundi … "6" = Dimanche

        Le set déduplique automatiquement les lignes matin/après-midi
        qui peuvent exister pour le même dayofweek dans un calendrier
        avec des shifts séparés AM/PM.
        """
        calendar = employee.resource_calendar_id
        if calendar and calendar.attendance_ids:
            work_days = {int(a.dayofweek) for a in calendar.attendance_ids}
        else:
            work_days = {0, 1, 2, 3, 4}   # Lundi-Vendredi par défaut

        result = []
        cursor = d_start
        while cursor <= d_end:
            if cursor.weekday() in work_days:
                result.append(cursor)
            cursor += timedelta(days=1)
        return result

    # ================================================================
    #  UTILITAIRES
    # ================================================================

    @staticmethod
    def _format_period(d_start, d_end):
        fmt = "%d %b"
        if d_start.year == d_end.year:
            return f"{d_start.strftime(fmt)} -> {d_end.strftime(fmt)} {d_end.year}"
        return (
            f"{d_start.strftime(fmt + ' %Y')} -> "
            f"{d_end.strftime(fmt + ' %Y')}"
        )

    def _empty(self, d_start, d_end, calc_end):
        return {
            "rate"               : 0.0,
            "working_days_done"  : 0,
            "working_days_total" : 0,
            "period_label"       : self._format_period(d_start, d_end),
            "date_start"         : d_start.isoformat(),
            "date_end"           : d_end.isoformat(),
            "calculation_end"    : calc_end.isoformat(),
            "department_id"      : False,
        }
        

# -*- coding: utf-8 -*-
"""
HRMIS — Contrôleur KPI 2 : Taux d'absence non justifiée
Fichier  : controllers/unauthorized_absence.py
Route    : POST /hrmis/kpi/unauthorized-absence-rate

═══════════════════════════════════════════════════════════════════════
DÉFINITION MÉTIER
═══════════════════════════════════════════════════════════════════════

Absence non justifiée = jour ouvrable attendu (ni férié, ni congé validé)
                        pour lequel AUCUN check-in n'existe dans hr_attendance.

Taux = Σ(jours absents non justifiés par agent)
       ─────────────────────────────────────────  × 100
       Σ(jours attendus par agent)

La même logique de biais de recrutement est appliquée :
    emp_start = max(date_start_filtre, date_début_contrat)

═══════════════════════════════════════════════════════════════════════
ROUTE SECONDAIRE — ALERTES CONSÉCUTIVES
═══════════════════════════════════════════════════════════════════════

Route : POST /hrmis/kpi/consecutive-absences
Retourne la liste des agents avec N jours consécutifs sans pointage
(ni congé validé, ni jour férié) pour alimenter le tableau d'alertes.

Paramètre optionnel : threshold (int, défaut 3)
    → n'inclut que les agents avec >= threshold jours consécutifs
"""


# ════════════════════════════════════════════════════════════════════
#  MIXIN PARTAGÉ — logique commune avec attendance.py
# ════════════════════════════════════════════════════════════════════

class _AbsenceMixin:
    """
    Regroupe les méthodes de bas niveau réutilisées par les deux
    contrôleurs (unauthorized_absence + consecutive_absences).
    Pas de route propre — jamais enregistré directement.
    """

    def _resolve_dates(self, date_start, date_end):
        today = date.today()
        d_start = (
            date.fromisoformat(date_start)
            if date_start
            else date(today.year, 1, 1)
        )
        d_end = (
            date.fromisoformat(date_end)
            if date_end
            else date(today.year, 12, 31)
        )
        if d_start > d_end:
            d_start, d_end = d_end, d_start
        return d_start, d_end

    def _get_active_employees(self, department_id=None):
        domain = [
            ("active", "=", True),
            ("contract_ids.state", "=", "open"),
        ]
        if department_id:
            domain.append(("department_id", "=", int(department_id)))
        return request.env["hr.employee"].search(domain)

    def _get_contract_start_dates(self, employee_ids, d_start):
        if not employee_ids:
            return {}
        request.env.cr.execute(
            """
            SELECT employee_id, MIN(date_start) AS contract_start
            FROM   hr_contract
            WHERE  employee_id = ANY(%s)
              AND  state = 'open'
              AND  date_start IS NOT NULL
            GROUP  BY employee_id
            """,
            (list(employee_ids),),
        )
        rows = request.env.cr.fetchall()
        result = {}
        for emp_id, contract_start in rows:
            result[emp_id] = max(d_start, contract_start) if contract_start else d_start
        for emp_id in employee_ids:
            if emp_id not in result:
                result[emp_id] = d_start
        return result

    def _fetch_pointed_days(self, employee_ids, d_start, d_end):
        """Set de (employee_id, date) — SQL brut, fix Odoo 18."""
        if not employee_ids:
            return set()
        request.env.cr.execute(
            """
            SELECT employee_id,
                   DATE(check_in AT TIME ZONE 'UTC') AS check_date
            FROM   hr_attendance
            WHERE  employee_id = ANY(%s)
              AND  check_in >= %s
              AND  check_in <= %s
            GROUP  BY employee_id, DATE(check_in AT TIME ZONE 'UTC')
            """,
            (
                list(employee_ids),
                f"{d_start} 00:00:00",
                f"{d_end} 23:59:59",
            ),
        )
        return {(r[0], r[1]) for r in request.env.cr.fetchall()}

    def _fetch_leave_days(self, employee_ids, d_start, d_end):
        """Set de (employee_id, date) — congés validés."""
        if not employee_ids:
            return set()
        leaves = request.env["hr.leave"].search([
            ("employee_id", "in", list(employee_ids)),
            ("state",       "=",  "validate"),
            ("date_from",   "<=", f"{d_end} 23:59:59"),
            ("date_to",     ">=", f"{d_start} 00:00:00"),
        ])
        leave_days = set()
        for leave in leaves:
            lv_start = max(leave.date_from.date(), d_start)
            lv_end   = min(leave.date_to.date(),   d_end)
            cursor   = lv_start
            while cursor <= lv_end:
                leave_days.add((leave.employee_id.id, cursor))
                cursor += timedelta(days=1)
        return leave_days

    def _fetch_off_days(self, employees, d_start, d_end):
        """Dict {employee_id: set(date)} — fériés et fermetures."""
        off_days    = {emp.id: set() for emp in employees}
        all_emp_ids = {emp.id for emp in employees}

        cal_to_emps  = {}
        dept_to_emps = {}
        for emp in employees:
            if emp.resource_calendar_id:
                cal_to_emps.setdefault(emp.resource_calendar_id.id, []).append(emp.id)
            if emp.department_id:
                dept_to_emps.setdefault(emp.department_id.id, []).append(emp.id)

        # Source 1 : fermetures calendrier
        try:
            for cl in request.env["resource.calendar.leaves"].search([
                ("calendar_id", "in", list(cal_to_emps.keys())),
                ("date_from",   "<=", f"{d_end} 23:59:59"),
                ("date_to",     ">=", f"{d_start} 00:00:00"),
                ("resource_id", "=",  False),
            ]):
                emp_ids  = cal_to_emps.get(cl.calendar_id.id, [])
                cl_start = max(cl.date_from.date(), d_start)
                cl_end   = min(cl.date_to.date(),   d_end)
                cursor   = cl_start
                while cursor <= cl_end:
                    for eid in emp_ids:
                        off_days[eid].add(cursor)
                    cursor += timedelta(days=1)
        except Exception:
            pass

        # Source 2 : jours fériés légaux (hr.leave.mandatory.day — Odoo 16+)
        try:
            for ml in request.env["hr.leave.mandatory.day"].search([
                ("start_date", "<=", str(d_end)),
                ("end_date",   ">=", str(d_start)),
            ]):
                ml_start = max(date.fromisoformat(str(ml.start_date)[:10]), d_start)
                ml_end   = min(date.fromisoformat(str(ml.end_date)[:10]),   d_end)
                concerned = set()
                if ml.department_ids:
                    for dept in ml.department_ids:
                        concerned.update(dept_to_emps.get(dept.id, []))
                else:
                    concerned = all_emp_ids
                cursor = ml_start
                while cursor <= ml_end:
                    for eid in concerned:
                        off_days[eid].add(cursor)
                    cursor += timedelta(days=1)
        except Exception:
            pass

        return off_days

    def _get_working_days(self, employee, d_start, d_end):
        calendar = employee.resource_calendar_id
        if calendar and calendar.attendance_ids:
            work_days = {int(a.dayofweek) for a in calendar.attendance_ids}
        else:
            work_days = {0, 1, 2, 3, 4}
        result = []
        cursor = d_start
        while cursor <= d_end:
            if cursor.weekday() in work_days:
                result.append(cursor)
            cursor += timedelta(days=1)
        return result

    @staticmethod
    def _format_period(d_start, d_end):
        fmt = "%d %b"
        if d_start.year == d_end.year:
            return f"{d_start.strftime(fmt)} -> {d_end.strftime(fmt)} {d_end.year}"
        return (
            f"{d_start.strftime(fmt + ' %Y')} -> "
            f"{d_end.strftime(fmt + ' %Y')}"
        )

    def _empty_rate(self, d_start, d_end, calc_end, department_id):
        return {
            "rate"                    : 0.0,
            "unauthorized_days"       : 0,
            "working_days_total"      : 0,
            "period_label"            : self._format_period(d_start, d_end),
            "date_start"              : d_start.isoformat(),
            "date_end"                : d_end.isoformat(),
            "calculation_end"         : calc_end.isoformat(),
            "department_id"           : int(department_id) if department_id else False,
        }


# ════════════════════════════════════════════════════════════════════
#  CONTRÔLEUR 1 — TAUX D'ABSENCE NON JUSTIFIÉE
# ════════════════════════════════════════════════════════════════════

class UnauthorizedAbsenceRateController(_AbsenceMixin, http.Controller):
    """
    POST /hrmis/kpi/unauthorized-absence-rate

    Payload JSON (tous optionnels) :
        date_start    (str ISO, défaut 01/01 année en cours)
        date_end      (str ISO, défaut 31/12 année en cours)
        department_id (int)

    Réponse :
        rate                  (float)   — % jours absents non justifiés / jours attendus
        unauthorized_days     (int)     — numérateur
        working_days_total    (int)     — dénominateur
        period_label          (str)
        date_start / date_end / calculation_end (str ISO)
        department_id         (int|False)
    """

    @http.route(
        "/hrmis/kpi/unauthorized-absence-rate",
        type="json",
        auth="user",
        methods=["POST"],
        csrf=True,
    )
    def get_unauthorized_absence_rate(self, **kwargs):
        date_start    = kwargs.get("date_start")
        date_end      = kwargs.get("date_end")
        department_id = kwargs.get("department_id")

        d_start, d_end = self._resolve_dates(date_start, date_end)
        calc_end = min(d_end, date.today())

        if d_start > calc_end:
            return self._empty_rate(d_start, d_end, calc_end, department_id)

        employees = self._get_active_employees(department_id)
        if not employees:
            return self._empty_rate(d_start, d_end, calc_end, department_id)

        contract_start_by_emp = self._get_contract_start_dates(employees.ids, d_start)
        pointed_days          = self._fetch_pointed_days(employees.ids, d_start, calc_end)
        leave_days            = self._fetch_leave_days(employees.ids, d_start, calc_end)
        off_days              = self._fetch_off_days(employees, d_start, calc_end)

        total_exp    = 0
        total_absent = 0

        for emp in employees:
            emp_start = contract_start_by_emp.get(emp.id, d_start)
            if emp_start > calc_end:
                continue

            emp_off      = off_days.get(emp.id, set())
            working_days = self._get_working_days(emp, emp_start, calc_end)

            for day in working_days:
                if day in emp_off:
                    continue
                if (emp.id, day) in leave_days:
                    continue

                # Jour attendu
                total_exp += 1

                # Absent non justifié = pas de check-in ce jour
                if (emp.id, day) not in pointed_days:
                    total_absent += 1

        if total_exp == 0:
            return self._empty_rate(d_start, d_end, calc_end, department_id)

        return {
            "rate"               : round((total_absent / total_exp) * 100, 1),
            "unauthorized_days"  : total_absent,
            "working_days_total" : total_exp,
            "period_label"       : self._format_period(d_start, d_end),
            "date_start"         : d_start.isoformat(),
            "date_end"           : d_end.isoformat(),
            "calculation_end"    : calc_end.isoformat(),
            "department_id"      : int(department_id) if department_id else False,
        }

class ConsecutiveAbsencesController(_AbsenceMixin, http.Controller):

    @http.route(
        "/hrmis/kpi/consecutive-absences",
        type="json",
        auth="user",
        methods=["POST"],
        csrf=True,
    )
    def get_consecutive_absences(self, **kwargs):
        department_id = kwargs.get("department_id")
        threshold     = int(kwargs.get("threshold", 3))

        # Fenêtre fixe — indépendante du filtre UI
        calc_end = date.today()
        d_start  = date(calc_end.year, 1, 1)

        employees = self._get_active_employees(department_id)
        if not employees:
            return {
                "alerts"          : [],
                "threshold"       : threshold,
                "date_start"      : d_start.isoformat(),
                "date_end"        : calc_end.isoformat(),
                "calculation_end" : calc_end.isoformat(),
            }

        contract_start_by_emp = self._get_contract_start_dates(employees.ids, d_start)
        pointed_days          = self._fetch_pointed_days(employees.ids, d_start, calc_end)
        leave_days            = self._fetch_leave_days(employees.ids, d_start, calc_end)
        off_days              = self._fetch_off_days(employees, d_start, calc_end)
        last_checkin_by_emp   = self._fetch_last_checkin_dates(employees.ids, d_start, calc_end)

        alerts = []

        for emp in employees:
            emp_start = contract_start_by_emp.get(emp.id, d_start)
            if emp_start > calc_end:
                continue

            emp_off      = off_days.get(emp.id, set())
            working_days = self._get_working_days(emp, emp_start, calc_end)

            current_streak = 0

            for day in working_days:
                if day in emp_off or (emp.id, day) in leave_days:
                    current_streak = 0
                    continue
                if (emp.id, day) not in pointed_days:
                    current_streak += 1
                else:
                    current_streak = 0

            if current_streak < threshold:
                continue

            # Calcul de "since"
            last_checkin = last_checkin_by_emp.get(emp.id)
            if last_checkin is None:
                # Jamais pointé → absent depuis le début de son contrat
                since = emp_start
            else:
                # A déjà pointé → absent depuis le lendemain ouvrable
                since = self._next_working_day(emp, last_checkin)

            alerts.append({
                "employee_id"      : emp.id,
                "name"             : emp.name,
                "department"       : emp.department_id.name if emp.department_id else "",
                "job_position"     : emp.job_id.name if emp.job_id else "",
                "consecutive_days" : current_streak,
                "since"            : since.isoformat(),
                "email"            : emp.work_email or "",
                "phone"            : emp.work_phone or emp.mobile_phone or "",
            })

        alerts.sort(key=lambda x: x["consecutive_days"], reverse=True)

        return {
            "alerts"          : alerts,
            "threshold"       : threshold,
            "date_start"      : d_start.isoformat(),
            "date_end"        : calc_end.isoformat(),
            "calculation_end" : calc_end.isoformat(),
        }
        
    def _fetch_last_checkin_dates(self, employee_ids, d_start, d_end):
        if not employee_ids:
            return {}
        request.env.cr.execute(
            """
            SELECT employee_id,
                   MAX(DATE(check_in AT TIME ZONE 'UTC')) AS last_date
            FROM   hr_attendance
            WHERE  employee_id = ANY(%s)
              AND  check_in >= %s
              AND  check_in <= %s
            GROUP  BY employee_id
            """,
            (list(employee_ids), f"{d_start} 00:00:00", f"{d_end} 23:59:59"),
        )
        return {r[0]: r[1] for r in request.env.cr.fetchall()}

    def _next_working_day(self, employee, from_date):
        calendar = employee.resource_calendar_id
        if calendar and calendar.attendance_ids:
            work_days = {int(a.dayofweek) for a in calendar.attendance_ids}
        else:
            work_days = {0, 1, 2, 3, 4}
        cursor = from_date + timedelta(days=1)
        for _ in range(14):
            if cursor.weekday() in work_days:
                return cursor
            cursor += timedelta(days=1)
        return from_date + timedelta(days=1)
    
 
class AttendanceMonthlyController(http.Controller):
 
    @http.route(
        "/hrmis/kpi/attendance-monthly",
        type="json",
        auth="user",
        methods=["POST"],
        csrf=True,
    )
    def get_attendance_monthly(self, **kwargs):
        date_start    = kwargs.get("date_start")
        date_end      = kwargs.get("date_end")
        department_id = kwargs.get("department_id")
        today         = date.today()
 
        # ── Bornes de la période ──────────────────────────────────────
        d_start = (
            date.fromisoformat(date_start)
            if date_start else date(today.year, 1, 1)
        )
        d_end = (
            date.fromisoformat(date_end)
            if date_end else date(today.year, 12, 31)
        )
        if d_start > d_end:
            d_start, d_end = d_end, d_start
 
        # ── Agents actifs avec contrat ouvert ─────────────────────────
        domain = [("active", "=", True), ("contract_ids.state", "=", "open")]
        if department_id:
            domain.append(("department_id", "=", int(department_id)))
        employees = request.env["hr.employee"].search(domain)
 
        if not employees:
            return self._empty_response(d_start, d_end, department_id)
 
        # ── Date de début de contrat par agent ────────────────────────
        contract_start_by_emp = self._get_contract_start_dates(
            employees.ids, d_start
        )
 
        # ── Données globales chargées UNE SEULE FOIS pour toute la période
        #    (évite N requêtes SQL, une par mois)
        pointed_days = self._fetch_pointed_days(employees.ids, d_start, d_end)
        leave_days   = self._fetch_leave_days(employees.ids, d_start, d_end)
        off_days     = self._fetch_off_days(employees, d_start, d_end)
 
        # Calendriers de travail par agent (calculé une fois)
        work_days_by_emp = {
            emp.id: self._get_work_weekdays(emp)
            for emp in employees
        }
 
        # ── Génération des mois ───────────────────────────────────────
        months_data = []
        current = date(d_start.year, d_start.month, 1)
 
        while current <= d_end:
            # Bornes du mois
            last_day  = cal_mod.monthrange(current.year, current.month)[1]
            month_end = date(current.year, current.month, last_day)
 
            # Intersection avec la période filtrée
            m_start = max(current, d_start)
            m_end   = min(month_end, d_end)
 
            # calc_end du mois : jamais dans le futur
            m_calc_end = min(m_end, today)
 
            label = current.strftime("%b %Y")
            key   = current.strftime("%Y-%m")
 
            if m_start > m_calc_end:
                # Mois entièrement dans le futur → null
                months_data.append({
                    "month"              : key,
                    "label"              : label,
                    "attendance_rate"    : 0,
                    "absence_rate"       : 0,
                    "working_days_done"  : 0,
                    "working_days_total" : 0,
                })
            else:
                total_exp, total_ptr = self._compute_month(
                    employees,
                    m_start,
                    m_calc_end,
                    contract_start_by_emp,
                    pointed_days,
                    leave_days,
                    off_days,
                    work_days_by_emp,
                )
 
                if total_exp == 0:
                    att_rate = 0
                    abs_rate = 0
                else:
                    att_rate = round((total_ptr / total_exp) * 100, 1)
                    abs_rate = round(100 - att_rate, 1)
 
                months_data.append({
                    "month"              : key,
                    "label"              : label,
                    "attendance_rate"    : att_rate,
                    "absence_rate"       : abs_rate,
                    "working_days_done"  : total_ptr,
                    "working_days_total" : total_exp,
                })
 
            # Mois suivant
            if current.month == 12:
                current = date(current.year + 1, 1, 1)
            else:
                current = date(current.year, current.month + 1, 1)
 
        return {
            "months"        : months_data,
            "date_start"    : d_start.isoformat(),
            "date_end"      : d_end.isoformat(),
            "department_id" : int(department_id) if department_id else False,
        }
 
    # ================================================================
    #  CALCUL POUR UN MOIS
    # ================================================================
 
    def _compute_month(
        self, employees, m_start, m_calc_end,
        contract_start_by_emp, pointed_days, leave_days,
        off_days, work_days_by_emp,
    ):
        total_exp = 0
        total_ptr = 0
 
        for emp in employees:
            emp_start = contract_start_by_emp.get(emp.id, m_start)
            if emp_start > m_calc_end:
                continue
 
            # Début effectif pour ce mois
            eff_start    = max(emp_start, m_start)
            emp_off      = off_days.get(emp.id, set())
            work_weekdays = work_days_by_emp.get(emp.id, {0, 1, 2, 3, 4})
 
            cursor = eff_start
            while cursor <= m_calc_end:
                if cursor.weekday() in work_weekdays:
                    if cursor not in emp_off and (emp.id, cursor) not in leave_days:
                        total_exp += 1
                        if (emp.id, cursor) in pointed_days:
                            total_ptr += 1
                cursor += timedelta(days=1)
 
        return total_exp, total_ptr
 
    # ================================================================
    #  MÉTHODES PARTAGÉES (dupliquées ici pour autonomie du contrôleur)
    # ================================================================
 
    def _get_contract_start_dates(self, employee_ids, d_start):
        if not employee_ids:
            return {}
        request.env.cr.execute(
            """
            SELECT employee_id, MIN(date_start) AS contract_start
            FROM   hr_contract
            WHERE  employee_id = ANY(%s)
              AND  state = 'open'
              AND  date_start IS NOT NULL
            GROUP  BY employee_id
            """,
            (list(employee_ids),),
        )
        result = {}
        for emp_id, contract_start in request.env.cr.fetchall():
            result[emp_id] = max(d_start, contract_start) if contract_start else d_start
        for emp_id in employee_ids:
            if emp_id not in result:
                result[emp_id] = d_start
        return result
 
    def _fetch_pointed_days(self, employee_ids, d_start, d_end):
        if not employee_ids:
            return set()
        request.env.cr.execute(
            """
            SELECT employee_id,
                   DATE(check_in AT TIME ZONE 'UTC') AS check_date
            FROM   hr_attendance
            WHERE  employee_id = ANY(%s)
              AND  check_in >= %s
              AND  check_in <= %s
            GROUP  BY employee_id, DATE(check_in AT TIME ZONE 'UTC')
            """,
            (list(employee_ids), f"{d_start} 00:00:00", f"{d_end} 23:59:59"),
        )
        return {(r[0], r[1]) for r in request.env.cr.fetchall()}
 
    def _fetch_leave_days(self, employee_ids, d_start, d_end):
        if not employee_ids:
            return set()
        leaves = request.env["hr.leave"].search([
            ("employee_id", "in", list(employee_ids)),
            ("state",       "=",  "validate"),
            ("date_from",   "<=", f"{d_end} 23:59:59"),
            ("date_to",     ">=", f"{d_start} 00:00:00"),
        ])
        leave_days = set()
        for leave in leaves:
            lv_start = max(leave.date_from.date(), d_start)
            lv_end   = min(leave.date_to.date(),   d_end)
            cursor   = lv_start
            while cursor <= lv_end:
                leave_days.add((leave.employee_id.id, cursor))
                cursor += timedelta(days=1)
        return leave_days
 
    def _fetch_off_days(self, employees, d_start, d_end):
        off_days    = {emp.id: set() for emp in employees}
        all_emp_ids = {emp.id for emp in employees}
        cal_to_emps = {}
        dept_to_emps = {}
        for emp in employees:
            if emp.resource_calendar_id:
                cal_to_emps.setdefault(emp.resource_calendar_id.id, []).append(emp.id)
            if emp.department_id:
                dept_to_emps.setdefault(emp.department_id.id, []).append(emp.id)
        try:
            for cl in request.env["resource.calendar.leaves"].search([
                ("calendar_id", "in", list(cal_to_emps.keys())),
                ("date_from",   "<=", f"{d_end} 23:59:59"),
                ("date_to",     ">=", f"{d_start} 00:00:00"),
                ("resource_id", "=",  False),
            ]):
                emp_ids  = cal_to_emps.get(cl.calendar_id.id, [])
                cl_start = max(cl.date_from.date(), d_start)
                cl_end   = min(cl.date_to.date(),   d_end)
                cursor   = cl_start
                while cursor <= cl_end:
                    for eid in emp_ids:
                        off_days[eid].add(cursor)
                    cursor += timedelta(days=1)
        except Exception:
            pass
        try:
            for ml in request.env["hr.leave.mandatory.day"].search([
                ("start_date", "<=", str(d_end)),
                ("end_date",   ">=", str(d_start)),
            ]):
                ml_start  = max(date.fromisoformat(str(ml.start_date)[:10]), d_start)
                ml_end    = min(date.fromisoformat(str(ml.end_date)[:10]),   d_end)
                concerned = set()
                if ml.department_ids:
                    for dept in ml.department_ids:
                        concerned.update(dept_to_emps.get(dept.id, []))
                else:
                    concerned = all_emp_ids
                cursor = ml_start
                while cursor <= ml_end:
                    for eid in concerned:
                        off_days[eid].add(cursor)
                    cursor += timedelta(days=1)
        except Exception:
            pass
        return off_days
 
    def _get_work_weekdays(self, employee):
        """Retourne le set des numéros de jour ouvrable (0=Lun…6=Dim)."""
        calendar = employee.resource_calendar_id
        if calendar and calendar.attendance_ids:
            return {int(a.dayofweek) for a in calendar.attendance_ids}
        return {0, 1, 2, 3, 4}
 
    def _empty_response(self, d_start, d_end, department_id):
        return {
            "months"        : [],
            "date_start"    : d_start.isoformat(),
            "date_end"      : d_end.isoformat(),
            "department_id" : int(department_id) if department_id else False,
        }
 
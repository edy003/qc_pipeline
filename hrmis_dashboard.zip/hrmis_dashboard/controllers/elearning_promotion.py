# -*- coding: utf-8 -*-

from odoo import http
from odoo.http import request
from odoo import fields


class ELearningDashboardController(http.Controller):

    @http.route("/hrmis/dashboard/departments", type="json", auth="user")
    def get_departments(self):
        return request.env["hr.department"].sudo().search_read(
            [], ["id", "name"], order="name asc"
        )

    @http.route("/hrmis/dashboard/employees", type="json", auth="user")
    def get_employees(self, department_id=None):
        domain = [("active", "=", True)]
        if department_id:
            domain.append(("department_id", "=", int(department_id)))
        return request.env["hr.employee"].sudo().search_read(
            domain, ["id", "name"], order="name asc"
        )

    @http.route("/hrmis/dashboard/kpi/courses_joined", type="json", auth="user")
    def get_courses_joined_kpi(self, department_id=None, employee_id=None):
        employees = self._get_employees(department_id, employee_id)

        # Un cours peut être rejoint par plusieurs employés → on déduplique par channel_id
        distinct_channels = set()
        for emp in employees:
            for membership in emp.mgfdp_course_membership_ids:
                distinct_channels.add(membership.channel_id.id)

        return {"count": len(distinct_channels)}
    
    @http.route("/hrmis/dashboard/kpi/cert_attempts", type="json", auth="user")
    def get_cert_attempts_kpi(self, department_id=None, employee_id=None):
        employees = self._get_employees(department_id, employee_id)
        total = sum(emp.mgfdp_cert_attempt_count for emp in employees)
        return {"count": total}

    @http.route("/hrmis/dashboard/kpi/avg_completion", type="json", auth="user")
    def get_avg_completion_kpi(self, department_id=None, employee_id=None):
        employees = self._get_employees(department_id, employee_id)
    
        total_completion = 0
        total_participations = 0
    
        for emp in employees:
            participations = emp.mgfdp_course_membership_ids
            total_completion    += sum(participations.mapped("completion"))
            total_participations += len(participations)
    
        avg = round(total_completion / total_participations, 2) if total_participations else 0.0
    
        return {"value": avg}
    
    @http.route("/hrmis/dashboard/charts/course_status", type="json", auth="user")
    def get_course_status_chart(self, department_id=None, employee_id=None):
        employees = self._get_employees(department_id, employee_id)

        # Pour chaque cours distinct → statut le plus avancé
        # completed > joined/ongoing (joined = déjà ongoing automatiquement)
        best_status_per_course = {}  # channel_id → "joined" | "completed"

        for emp in employees:
            for membership in emp.mgfdp_course_membership_ids:
                cid = membership.channel_id.id
                status = membership.member_status

                current = best_status_per_course.get(cid)
                # completed écrase tout, sinon on garde joined
                if current != "completed":
                    if status == "completed":
                        best_status_per_course[cid] = "completed"
                    else:
                        best_status_per_course[cid] = "joined"

        joined    = sum(1 for s in best_status_per_course.values() if s == "joined")
        completed = sum(1 for s in best_status_per_course.values() if s == "completed")

        return {
            "labels": ["On going", "Completed"],
            "data"  : [joined, completed],
            "total" : joined + completed,
        }
        
    @http.route("/hrmis/dashboard/charts/cert_status", type="json", auth="user")
    def get_cert_status_chart(self, department_id=None, employee_id=None):
        employees = self._get_employees(department_id, employee_id)

        total_attempts = 0
        total_success = 0
        total_failed = 0

        for emp in employees:
            done_inputs = emp.mgfdp_certification_input_ids.filtered(
                lambda i: i.state == "done"
            )
            passed = done_inputs.filtered("scoring_success")
            failed = done_inputs - passed

            total_attempts += len(done_inputs)
            total_success += len(passed)
            total_failed += len(failed)

        return {
            "labels": ["Passed", "Failed"],
            "data": [total_success, total_failed],
            "total": total_attempts,
        }
        
    @http.route("/hrmis/dashboard/promotions", type="json", auth="user")
    def get_promotions(self, year=None, department_id=None, employee_id=None):
        employees = self._get_employees(department_id, employee_id)
        employee_ids = employees.ids
    
        if not employee_ids:
            return []
    
        domain = [("employee_id", "in", employee_ids)]
    
        if year:
            domain += [
                ("decision_date", ">=", f"{year}-01-01 00:00:00"),
                ("decision_date", "<=", f"{year}-12-31 23:59:59"),
            ]
    
        promotions = request.env["mgfdp.promotion.history"].sudo().search(domain)
    
        result = []
        for p in promotions:
            result.append({
                "id": p.id,
                "employee_name": p.employee_id.name,
                "old_grade": p.old_grade_id.name,
                "new_grade": p.new_grade_id.name,
                "was_eligible": p.was_eligible,
                "decided_by": p.decided_by_id.name,
                "reason": p.reason or "",
                "decision_date": p.decision_date.strftime("%Y-%m-%d %H:%M") if p.decision_date else "",
            })
    
        return result


    @http.route("/hrmis/dashboard/promotions/years", type="json", auth="user")
    def get_promotion_years(self, department_id=None, employee_id=None):
        """Retourne les années distinctes disponibles en BD pour le filtre."""
        employees = self._get_employees(department_id, employee_id)
        employee_ids = employees.ids
    
        if not employee_ids:
            [fields.Datetime.now().year]
     
        request.env.cr.execute("""
            SELECT DISTINCT EXTRACT(YEAR FROM decision_date)::int AS yr
            FROM mgfdp_promotion_history
            WHERE employee_id = ANY(%s)
            ORDER BY yr DESC
        """, (employee_ids,))
    
        rows = request.env.cr.fetchall()
        current_year = fields.Datetime.now().year
    
        years = [r[0] for r in rows] if rows else []
        if current_year not in years:
            years.insert(0, current_year)
    
        return years
    
    # ─── helper privé ────────────────────────────────────────────────────
    def _get_employees(self, department_id=None, employee_id=None):
        domain = [("active", "=", True)]
        if employee_id:
            domain.append(("id", "=", int(employee_id)))
        elif department_id:
            domain.append(("department_id", "=", int(department_id)))
        return request.env["hr.employee"].sudo().search(domain)
# -*- coding: utf-8 -*-
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo import http
from odoo.http import request
import calendar


class EmployeeDashboardController(http.Controller):

    @http.route(
        "/hrmis/employee/kpis",
        type="json",
        auth="user",
        methods=["POST"],
    )
    def employee_kpis(self, filters=None):
        filters          = filters or {}
        department_id    = filters.get("department_id")    or False
        grade_id         = filters.get("grade_id")         or False
        contract_type_id = filters.get("contract_type_id") or False

        Employee = request.env["hr.employee"]
        Contract = request.env["hr.contract"]

        # ── Récupère les IDs des employés avec un contrat actif
        #    correspondant aux filtres grade + contract_type ──────────
        # Ces deux filtres vivent sur hr.contract, pas sur hr.employee.
        # On résout d'abord les IDs employés concernés, puis on filtre.

        filtered_employee_ids = None  # None = pas de restriction

        if grade_id or contract_type_id:
            contract_domain = [
                ("state",  "=", "open"),
                ("active", "=", True),
            ]
            if grade_id:
                contract_domain.append(("grade_id", "=", grade_id))
            if contract_type_id:
                contract_domain.append(("contract_type_id", "=", contract_type_id))
            if department_id:
                contract_domain.append(
                    ("employee_id.department_id", "=", department_id)
                )

            filtered_employee_ids = Contract.search(
                contract_domain
            ).mapped("employee_id.id")

        # ── KPI 1 : Total Employees ──────────────────────────────────
        emp_domain = [("active", "=", True)]
        if department_id:
            emp_domain.append(("department_id", "=", department_id))
        if filtered_employee_ids is not None:
            emp_domain.append(("id", "in", filtered_employee_ids))

        total_employees = Employee.search_count(emp_domain)

        # ── KPI 2 : Active Contracts ─────────────────────────────────
        contract_domain = [
            ("state",  "=", "open"),
            ("active", "=", True),
        ]
        if department_id:
            contract_domain.append(
                ("employee_id.department_id", "=", department_id)
            )
        if grade_id:
            contract_domain.append(("grade_id", "=", grade_id))
        if contract_type_id:
            contract_domain.append(("contract_type_id", "=", contract_type_id))

        active_contracts = Contract.search_count(contract_domain)

        # ── KPI 3 : Near Retirement (âge >= 60 ans) ──────────────────
        cutoff_date = date.today() - relativedelta(years=60)

        retirement_domain = [
            ("active",   "=", True),
            ("birthday", "!=", False),
            ("birthday", "<=", cutoff_date.strftime("%Y-%m-%d")),
        ]
        if department_id:
            retirement_domain.append(("department_id", "=", department_id))
        if filtered_employee_ids is not None:
            retirement_domain.append(("id", "in", filtered_employee_ids))

        near_retirement = Employee.search_count(retirement_domain)

        # ── KPI 4 : Vacant Positions ─────────────────────────────────
        vacant_domain = [("state", "in", ["vacant", "recruiting"])]
        if department_id:
            vacant_domain.append(("department_id", "=", department_id))
        if filtered_employee_ids is not None:
            vacant_domain.append(("former_employee_id", "in", filtered_employee_ids))
        vacant_positions = request.env["hr.vacant.position"].search_count(vacant_domain)


        return {
            "total_employees"  : total_employees,
            "active_contracts" : active_contracts,
            "near_retirement"  : near_retirement,
            "vacant_positions" : vacant_positions,
        }


    @http.route(
        "/hrmis/employee/chart/by-grade",
        type="json",
        auth="user",
        methods=["POST"],
    )
    def employee_chart_by_grade(self, filters=None):
        """
        Répartition par grade.
        Filtre grade_id = restreindre à CE grade uniquement
        (utile quand le filtre global envoie grade_id).
        """
        filters = filters or {}
        department_id = filters.get("department_id") or False
        contract_type_id = filters.get("contract_type_id") or False
        grade_id = filters.get("grade_id") or False # ✅ AJOUT
        contract_domain = [
            ("state", "=", "open"),
            ("active", "=", True),
        ]
        if department_id:
            contract_domain.append(
                ("employee_id.department_id", "=", department_id)
            )
        if contract_type_id:
            contract_domain.append(("contract_type_id", "=", contract_type_id))
        if grade_id: # ✅ AJOUT
            contract_domain.append(("grade_id", "=", grade_id)) # ✅ AJOUT
        contracts = request.env["hr.contract"].search_read(
            contract_domain,
            ["employee_id", "grade_id"],
        )
        grade_counts = {}
        no_grade_count = 0
        for contract in contracts:
            if contract["grade_id"]:
                grade_name = contract["grade_id"][1]
                grade_counts[grade_name] = grade_counts.get(grade_name, 0) + 1
            else:
                no_grade_count += 1
        sorted_grades = sorted(
            grade_counts.items(), key=lambda x: x[1], reverse=True
        )
        MAX_GRADES = 8
        top_grades = sorted_grades[:MAX_GRADES]
        others = sorted_grades[MAX_GRADES:]
        labels = [g[0] for g in top_grades]
        data = [g[1] for g in top_grades]
        others_count = sum(g[1] for g in others)
        if others_count > 0:
            labels.append("Autres")
            data.append(others_count)
        if no_grade_count > 0:
            labels.append("No grade")
            data.append(no_grade_count)
        return {"labels": labels, "data": data, "total": sum(data)}

    @http.route(
        "/hrmis/employee/chart/by-contract-type",
        type="json",
        auth="user",
        methods=["POST"],
    )
    def employee_chart_by_contract_type(self, filters=None):
        filters = filters or {}
        department_id = filters.get("department_id") or False
        grade_id = filters.get("grade_id") or False
        contract_type_id = filters.get("contract_type_id") or False # ✅ AJOUT
        contract_domain = [
            ("state", "=", "open"),
            ("active", "=", True),
        ]
        if department_id:
            contract_domain.append(
                ("employee_id.department_id", "=", department_id)
            )
        if grade_id:
            contract_domain.append(("grade_id", "=", grade_id))
        if contract_type_id: # ✅ AJOUT
            contract_domain.append(("contract_type_id", "=", contract_type_id))
        contracts = request.env["hr.contract"].search_read(
            contract_domain,
            ["employee_id", "contract_type_id"],
        )
        type_counts = {}
        no_type_count = 0
        for contract in contracts:
            if contract["contract_type_id"]:
                type_name = contract["contract_type_id"][1]
                type_counts[type_name] = type_counts.get(type_name, 0) + 1
            else:
                no_type_count += 1
        sorted_types = sorted(
            type_counts.items(), key=lambda x: x[1], reverse=True
        )
        labels = [t[0] for t in sorted_types]
        data = [t[1] for t in sorted_types]
        if no_type_count > 0:
            labels.append("No type")
            data.append(no_type_count)
        return {"labels": labels, "data": data, "total": sum(data)}
    

    @http.route(
        "/hrmis/employee/chart/vacant-by-department",
        type="json",
        auth="user",
        methods=["POST"],
        csrf=False,  # souvent utile pour les appels JSON en POST
    )
    def employee_chart_vacant_by_department(self, filters=None):
        """
        Répartition des postes vacants par département.

        Filtre department_id = restreindre à CE département uniquement.
        Filtre grade_id / contract_type_id = passer par former_employee_id
        (version 1 — sans grade/contract_type sur hr.vacant.position).
        """
        filters = filters or {}

        department_id = filters.get("department_id") or False
        grade_id = filters.get("grade_id") or False
        contract_type_id = filters.get("contract_type_id") or False

        # ── Résolution des IDs employés si filtre grade ou contract_type ────
        # Même logique que employee_kpis : ces filtres vivent sur hr.contract,
        # on résout d'abord les employés concernés.
        filtered_employee_ids = None
        if grade_id or contract_type_id:
            contract_domain = [
                ("state", "=", "open"),
                ("active", "=", True),
            ]
            if grade_id:
                contract_domain.append(("grade_id", "=", grade_id))
            if contract_type_id:
                contract_domain.append(("contract_type_id", "=", contract_type_id))
            if department_id:
                contract_domain.append(
                    ("employee_id.department_id", "=", department_id)
                )

            filtered_employee_ids = request.env["hr.contract"].search(
                contract_domain
            ).mapped("employee_id.id")

        # ── Domaine principal ────────────────────────────────────────────────
        vacant_domain = [("state", "in", ["vacant", "recruiting"])]

        if department_id:
            vacant_domain.append(("department_id", "=", department_id))

        if filtered_employee_ids is not None:
            vacant_domain.append(
                ("former_employee_id", "in", filtered_employee_ids)
            )

        # ── Récupération et agrégation par département ───────────────────────
        records = request.env["hr.vacant.position"].search_read(
            vacant_domain,
            ["department_id"],
        )
        
        dept_ids = [rec["department_id"][0] for rec in records if rec["department_id"]]
        dept_names_map = {
            dept.id: dept.name
            for dept in request.env["hr.department"].browse(dept_ids)
        }


        dept_counts = {}
        no_dept_count = 0

        for rec in records:
            if rec["department_id"]:
                dept_id = rec["department_id"][0]
                dept_name = dept_names_map.get(dept_id, rec["department_id"][1])  # fallback
                dept_counts[dept_name] = dept_counts.get(dept_name, 0) + 1
            else:
                no_dept_count += 1


        # Tri par nombre de postes vacants (descendant)
        sorted_depts = sorted(
            dept_counts.items(), key=lambda x: x[1], reverse=True
        )

        # ── Cap à 8 départements + regroupement "Autres" ─────────────────────
        MAX_DEPTS = 3
        top_depts = sorted_depts[:MAX_DEPTS]
        others = sorted_depts[MAX_DEPTS:]

        labels = [d[0] for d in top_depts]
        data = [d[1] for d in top_depts]

        others_count = sum(d[1] for d in others)
        if others_count > 0:
            labels.append("Others")
            data.append(others_count)

        if no_dept_count > 0:
            labels.append("No department")
            data.append(no_dept_count)

        return {
            "labels": labels,
            "data": data,
            "total": sum(data)
        }


    @http.route(
        "/hrmis/employee/chart/active-vs-retirement",
        type="json",
        auth="user",
        methods=["POST"],
    )
    def employee_chart_active_vs_retirement(self, filters=None):
        filters = filters or {}
        
        department_id = filters.get("department_id") or False
        grade_id = filters.get("grade_id") or False
        contract_type_id = filters.get("contract_type_id") or False
        
        date_from_str = filters.get("date_from") or f"{date.today().year}-01-01"
        date_to_str = filters.get("date_to") or f"{date.today().year}-12-31"
        
        date_from = date.fromisoformat(date_from_str)
        date_to = date.fromisoformat(date_to_str)

        Contract = request.env["hr.contract"]
        Retirement = request.env["hr.retirement"]

        # Génération des mois
        months = []
        cursor = date_from.replace(day=1)
        
        while cursor <= date_to:
            last_day = calendar.monthrange(cursor.year, cursor.month)[1]
            months.append({
                "label": cursor.strftime("%b %Y"),
                "month_start": cursor,
                "month_end": cursor.replace(day=last_day),
            })
            cursor = (
                cursor.replace(year=cursor.year + 1, month=1, day=1)
                if cursor.month == 12
                else cursor.replace(month=cursor.month + 1, day=1)
            )

        labels = []
        active_data = []
        retirement_data = []

        for m in months:
            month_start_str = m["month_start"].isoformat()
            month_end_str = m["month_end"].isoformat()

            # === Contrats actifs ===
            contract_domain = [
                ("state", "=", "open"),
                ("employee_id.active", "=", True),  # ← FIX : exclure les employés archivés
                ("date_start", "<=", month_end_str),
                "|",
                ("date_end", "=", False),
                ("date_end", ">=", month_start_str),
            ]

            if department_id:
                contract_domain.append(("employee_id.department_id", "=", department_id))
            if grade_id:
                contract_domain.append(("grade_id", "=", grade_id))
            if contract_type_id:
                contract_domain.append(("contract_type_id", "=", contract_type_id))

            active_count = Contract.search_count(contract_domain)

            # === Retraites ===
            retirement_domain = [
                ("state", "in", ["approved"]),  # ← FIX : approved compte aussi
                ("retirement_date", ">=", month_start_str),
                ("retirement_date", "<=", month_end_str),
            ]

            if department_id:
                retirement_domain.append(("employee_id.department_id", "=", department_id))
            if grade_id:
                retirement_domain.append(("employee_id.contract_ids.grade_id", "=", grade_id))
            if contract_type_id:
                retirement_domain.append(("employee_id.contract_ids.contract_type_id", "=", contract_type_id))

            retirement_count = Retirement.search_count(retirement_domain)

            # Ajout des données
            labels.append(m["label"])
            active_data.append(active_count)
            retirement_data.append(retirement_count)

        return {
            "labels": labels,
            "active_data": active_data,
            "retirement_data": retirement_data,
        }
    
    @http.route(
        "/hrmis/employee/dropdowns",
        type="json",
        auth="user",
        methods=["POST"],
    )
    def employee_dropdowns(self):
        """
        Retourne TOUS les grades et types de contrat existants,
        pas seulement ceux utilisés dans des contrats actifs.
        """
        departments = request.env["hr.department"].search_read(
            [("active", "=", True)],
            ["id", "name"],
            order="name asc",
        )
        # ✅ TOUS les grades actifs (pas de filtre sur les contrats)
        grades = request.env["hr.employee.grade"].search_read(
            [("active", "=", True)],
            ["id", "name"],
            order="name asc",
        )
        # ✅ TOUS les types de contrat (hr.contract.type n'a pas de champ active)
        contract_types = request.env["hr.contract.type"].search_read(
            [],
            ["id", "name"],
            order="name asc",
        )
        return {
            "departments" : departments,
            "grades" : grades,
            "contract_types" : contract_types,
        }
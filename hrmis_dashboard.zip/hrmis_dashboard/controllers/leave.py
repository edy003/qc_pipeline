# controllers/leave_dashboard.py

from odoo import http
from odoo.http import request
from datetime import date, datetime


class LeaveDashboardController(http.Controller):

    @http.route(
        '/hrmis/leave/dashboard',
        type='json',
        auth='user',
        methods=['POST'],
        csrf=False,
    )
    def get_leave_dashboard(self, **kwargs):
        filters = kwargs.get('filters', {})
        params  = self._parse_filters(filters)

        return {
            'kpi_leaves_in_progress': self._kpi_leaves_in_progress(params),
            'kpi_pending_approval'  : self._kpi_pending_approval(params),
            'kpi_long_leaves'       : self._kpi_long_leaves(params),
        }

    # ─────────────────────────────────────────────
    # PARSING DES FILTRES
    # ─────────────────────────────────────────────
    def _parse_filters(self, filters):
        today      = date.today()
        year_start = date(today.year, 1, 1)
        year_end   = date(today.year, 12, 31)

        # ── Dates ────────────────────────────────
        raw_date_from = filters.get('date_from')
        raw_date_to   = filters.get('date_to')

        try:
            date_from = (
                datetime.strptime(raw_date_from, '%Y-%m-%d').date()
                if raw_date_from else year_start
            )
        except (ValueError, TypeError):
            date_from = year_start

        try:
            date_to = (
                datetime.strptime(raw_date_to, '%Y-%m-%d').date()
                if raw_date_to else year_end
            )
        except (ValueError, TypeError):
            date_to = year_end

        if date_from > date_to:
            date_from, date_to = date_to, date_from

        # ── Département ──────────────────────────
        department_id = filters.get('department_id')
        try:
            department_id = int(department_id) if department_id else None
        except (ValueError, TypeError):
            department_id = None

        # ── Type de congé ─────────────────────────
        holiday_status_id = filters.get('holiday_status_id')
        try:
            holiday_status_id = int(holiday_status_id) if holiday_status_id else None
        except (ValueError, TypeError):
            holiday_status_id = None

        return {
            'date_from'        : date_from,
            'date_to'          : date_to,
            'department_id'    : department_id,
            'holiday_status_id': holiday_status_id,
            'today'            : today,
        }

    # ─────────────────────────────────────────────
    # KPI 1 — CONGÉS RÉELLEMENT EN COURS
    # ─────────────────────────────────────────────
    def _kpi_leaves_in_progress(self, params):
        """
        Congés RÉELLEMENT EN COURS aujourd'hui :
            ✅ state = 'validate'
            ✅ request_date_from <= aujourd'hui  (déjà commencé)
            ✅ request_date_to   >= aujourd'hui  (pas encore terminé)

        Les filtres date_from/date_to du dashboard servent uniquement
        à restreindre la plage de recherche (optionnel, ex: 
        "en cours dans l'année en cours").
        """
        today   = params['today']
        HrLeave = request.env['hr.leave'].sudo()

        domain = [
            # ── Congé validé ──────────────────────
            ('state'             , '=', 'validate'),

            # ── Congé ayant déjà commencé ─────────
            ('request_date_from' , '<=', today),

            # ── Congé pas encore terminé ──────────
            ('request_date_to'   , '>=', today),

            # ── Dans la plage de l'année en cours ─
            # (évite de remonter des années passées
            #  si les filtres ne sont pas actifs)
            ('request_date_from' , '>=', params['date_from']),
            ('request_date_to'   , '<=', params['date_to']),
        ]

        # ── Filtre département ────────────────────
        if params['department_id']:
            domain.append(
                ('employee_id.department_id', '=', params['department_id'])
            )

        # ── Filtre type de congé ──────────────────
        if params['holiday_status_id']:
            domain.append(
                ('holiday_status_id', '=', params['holiday_status_id'])
            )

        leaves = HrLeave.search(domain)

        # ── Calculs ───────────────────────────────
        count          = len(leaves)
        
        return {
            'count'         : count,
            'label'         : 'Congés en cours',
            'as_of_date'    : str(today),
        }

    def _kpi_pending_approval(self, params):
        HrLeave = request.env['hr.leave'].sudo()

        domain = [
            ('state'            , '=', 'confirm'),
            ('request_date_from', '>=', params['date_from']),  # ← année en cours
            ('request_date_from', '<=', params['date_to']),    # ← année en cours
        ]

        if params['department_id']:
            domain.append(('employee_id.department_id', '=', params['department_id']))

        if params['holiday_status_id']:
            domain.append(('holiday_status_id', '=', params['holiday_status_id']))

        return {
            'count': HrLeave.search_count(domain),
            'label': "En attente d'approbation",
        }
        
    # ─────────────────────────────────────────────
    # KPI 3 — CONGÉS VALIDÉS > 30 JOURS
    # ─────────────────────────────────────────────
    def _kpi_long_leaves(self, params):
        HrLeave = request.env['hr.leave'].sudo()

        domain = [
            ('state'            , '=', 'validate'),
            ('number_of_days'   , '>' , 30),
            ('request_date_from', '>=', params['date_from']),
            ('request_date_from', '<=', params['date_to']),
        ]

        if params['department_id']:
            domain.append(('employee_id.department_id', '=', params['department_id']))

        if params['holiday_status_id']:
            domain.append(('holiday_status_id', '=', params['holiday_status_id']))

        return {
            'count': HrLeave.search_count(domain),
            'label': 'Congés validés > 30 jours',
        }
        
    @http.route(
        '/hrmis/leave/chart/by-type',
        type='json',
        auth='user',
        methods=['POST'],
        csrf=False,
    )
    def get_chart_by_type(self, **kwargs):
        filters = kwargs.get('filters', {})
        params  = self._parse_filters(filters)

        HrLeave = request.env['hr.leave'].sudo()

        domain = [
            ('state'            , '=', 'validate'),
            ('request_date_from', '>=', params['date_from']),
            ('request_date_from', '<=', params['date_to']),
        ]

        if params['department_id']:
            domain.append(('employee_id.department_id', '=', params['department_id']))

        if params['holiday_status_id']:
            domain.append(('holiday_status_id', '=', params['holiday_status_id']))

        leaves = HrLeave.search(domain)

        # Grouper par type
        groups = {}
        for leave in leaves:
            name = leave.holiday_status_id.name or 'Inconnu'
            groups[name] = groups.get(name, 0) + 1

        # Trier par count décroissant
        sorted_groups = sorted(groups.items(), key=lambda x: x[1], reverse=True)

        # Garder les 5 premiers, regrouper le reste en "Autres"
        labels = []
        data   = []
        autres = 0

        for i, (name, count) in enumerate(sorted_groups):
            if i < 5:
                labels.append(name)
                data.append(count)
            else:
                autres += count

        if autres > 0:
            labels.append('Autres')
            data.append(autres)

        return {
            'labels': labels,
            'data'  : data,
        }
        
    @http.route(
        '/hrmis/leave/chart/approved-vs-refused',
        type='json',
        auth='user',
        methods=['POST'],
        csrf=False,
    )
    def get_chart_approved_vs_refused(self, **kwargs):
        filters = kwargs.get('filters', {})
        params  = self._parse_filters(filters)
    
        HrLeave = request.env['hr.leave'].sudo()
    
        domain = [
            ('state'            , 'in', ['validate', 'refuse']),
            ('request_date_from', '>=', params['date_from']),
            ('request_date_from', '<=', params['date_to']),
        ]
    
        if params['department_id']:
            domain.append(
                ('employee_id.department_id', '=', params['department_id'])
            )
    
        if params['holiday_status_id']:
            domain.append(
                ('holiday_status_id', '=', params['holiday_status_id'])
            )
    
        leaves = HrLeave.search(domain)
    
        approved = sum(1 for l in leaves if l.state == 'validate')
        refused  = sum(1 for l in leaves if l.state == 'refuse')
        total    = approved + refused
    
        return {
            'labels'  : ['Approuved', 'Refused'],
            'data'    : [approved, refused],
            'total'   : total,
        }
        
    # ─────────────────────────────────────────────
    # ROUTE — ÉVOLUTION MENSUELLE DES CONGÉS
    # ─────────────────────────────────────────────
    @http.route(
        '/hrmis/leave/chart/by-month',
        type='json',
        auth='user',
        methods=['POST'],
        csrf=False,
    )
    def get_chart_by_month(self, **kwargs):
        filters = kwargs.get('filters', {})
        params  = self._parse_filters(filters)

        HrLeave = request.env['hr.leave'].sudo()

        domain = [
            ('state'            , '=', 'validate'),
            ('request_date_from', '>=', params['date_from']),
            ('request_date_from', '<=', params['date_to']),
        ]

        if params['department_id']:
            domain.append(('employee_id.department_id', '=', params['department_id']))

        if params['holiday_status_id']:
            domain.append(('holiday_status_id', '=', params['holiday_status_id']))

        leaves = HrLeave.search(domain)

        # Initialiser les 12 mois à 0
        months = {m: 0 for m in range(1, 13)}

        for leave in leaves:
            month = leave.request_date_from.month
            months[month] += 1

        return {
            'labels': ['Janvier','Février','Mars','Avril','Mai','Juin',
                       'Juillet','Août','Septembre','Octobre','Novembre','Décembre'],
            'data'  : [months[m] for m in range(1, 13)],
        }
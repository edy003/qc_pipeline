# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError, UserError


class OpportunityIdentification(models.Model):
    _name = 'opportunity.identification'
    _description = 'Identification & Validation des Opportunités'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'deadline asc'

    # ── Identification ─────────────────────────────────────────────────────────
    category = fields.Selection([
        ('rfp',  'RFP'),
        ('reoi', 'REOI'),
        ('ami',  'AMI'),
        ('ddp',  'DDP'),
    ], string='Category', required=True, tracking=True)

    opportunity_type = fields.Selection([
        ('tc', 'Technologie (TC)'),
        ('co', 'Consulting (CO)'),
        ('fo', 'Formation (FO)'),
    ], string='Type', required=True, tracking=True)

    location           = fields.Many2one('res.country', string='Location', required=True)
    due_date           = fields.Date(string='Due Date', required=True, tracking=True)
    title              = fields.Char(string='Title', required=True)
    client             = fields.Char(string='Client', required=True)
    funding_partner    = fields.Char(string='Funding Partner')
    drive_link         = fields.Char(string='Documents')
    deadline           = fields.Date(string='Deadline', required=True, tracking=True)
    comments           = fields.Text(string='Comments')

    # ── Décision ───────────────────────────────────────────────────────────────
    go    = fields.Boolean(string='Go',    default=False, tracking=True, readonly=True)
    no_go = fields.Boolean(string='No-Go', default=False, tracking=True, readonly=True)

    decision_note = fields.Text(string='Note de décision')
    decision_date = fields.Datetime(string='Date de décision', readonly=True)
    decision_by   = fields.Many2one('res.users', string='Décidé par', readonly=True)

    # ── Assignees ──────────────────────────────────────────────────────────────
    lead_ids = fields.Many2many(
        'hr.employee', 'opp_lead_rel', 'opp_id', 'employee_id',
        string='Leads', tracking=True,
    )
    bd_assistant_ids = fields.Many2many(
        'hr.employee', 'opp_bd_rel', 'opp_id', 'employee_id',
        string='BD Assistants', tracking=True,
    )
    qa_ids = fields.Many2many(
        'hr.employee', 'opp_qa_rel', 'opp_id', 'employee_id',
        string='QA', tracking=True,
    )

    # ── Lien vers le QC Pipeline ───────────────────────────────────────────────
    qc_pipeline_id = fields.Many2one(
        'qc.opportunity', string='QC Pipeline', readonly=True,
    )

    # ── État du workflow ───────────────────────────────────────────────────────
    state = fields.Selection([
        ('new',                 'Nouveau'),
        ('submitted',           'En attente de validation'),
        ('go_ok',               'Go – En attente d\'assignation'),
        ('refused',             'Non suivi'),
        ('pipeline_registered', 'Enregistré dans la Pipeline'),
    ], default='new', tracking=True, string='Statut', readonly=True, copy=False)

    # ── Champ calculé : assignation complète ? ────────────────────────────────
    is_assigned = fields.Boolean(
        string='Équipe assignée',
        compute='_compute_is_assigned',
        store=True,
    )

    @api.depends('lead_ids')
    def _compute_is_assigned(self):
        for rec in self:
            rec.is_assigned = bool(rec.lead_ids)

    # ── Contrainte : go et no_go mutuellement exclusifs ───────────────────────
    @api.constrains('go', 'no_go')
    def _check_decision(self):
        for rec in self:
            if rec.go and rec.no_go:
                raise ValidationError(
                    "Go et No-Go ne peuvent pas être actifs simultanément."
                )
                
    # ==========================================================================
    # Helper email
    # ==========================================================================

    def _build_html_submitted(self):
        """HTML pour la notification de soumission."""
        self.ensure_one()
        location = self.location.name if self.location else '-'
        funding_row = ''
        if self.funding_partner:
            funding_row = f"""
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Bailleur</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.funding_partner}</td>
            </tr>"""

        return f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
        <p>Bonjour,</p>
        <p>
            L'opportunité <strong>{self.title}</strong>
            ({self.category.upper()})
            au <strong>{location}</strong>
            vous a été soumise pour validation par
            <strong>{self.env.user.name}</strong>.
        </p>
        <table style="width:100%; border-collapse:collapse; margin:16px 0;">
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; width:40%; border:1px solid #ddd;">Catégorie</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.category.upper()}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Client</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.client or '-'}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Deadline</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.deadline}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Localisation</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{location}</td>
            </tr>
            {funding_row}
        </table>
        <p>Merci de vous connecter à Odoo pour donner votre décision <strong>GO / NO-GO</strong>.</p>
        <p style="margin-top:24px;">
            Cordialement,<br/>
            <strong>{self.env.user.name}</strong>
        </p>
    </div>"""


    def _build_html_decision(self):
        """HTML pour la notification de décision GO/NO-GO."""
        self.ensure_one()
        decideur = self.decision_by.name if self.decision_by else 'le Validator'
    
        if self.go:
            decision_block = f"""
            <p style="padding:12px 16px; background:#eafaf1; border-left:4px solid #27ae60; border-radius:4px;">
                ✅ L'opportunité <strong>{self.title}</strong> a reçu une décision
                <strong style="color:#27ae60;">GO</strong> de la part de
                <strong>{decideur}</strong>.<br/>
                Vous pouvez procéder à l'assignation de l'équipe.
            </p>"""
        else:
            decision_block = f"""
            <p style="padding:12px 16px; background:#fdedec; border-left:4px solid #c0392b; border-radius:4px;">
                ❌ L'opportunité <strong>{self.title}</strong> a reçu une décision
                <strong style="color:#c0392b;">NO-GO</strong> de la part de
                <strong>{decideur}</strong>.<br/>
                Elle est classée <em>Non suivi</em>.
            </p>"""
    
        note_block = ''
        if self.decision_note:
            note_block = f"""
            <p style="padding:10px 14px; background:#fdfbe6; border-left:4px solid #f1c40f; border-radius:4px;">
                <strong>Note :</strong> {self.decision_note}
            </p>"""
    
        return f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
        <p>Bonjour,</p>
        {decision_block}
        <table style="width:100%; border-collapse:collapse; margin:16px 0;">
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; width:40%; border:1px solid #ddd;">Opportunité</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.title}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Catégorie</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.category.upper()}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Client</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.client or '-'}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Deadline</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.deadline}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Décidé par</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{decideur}</td>
            </tr>
            <tr>
                <td style="padding:6px 10px; background:#f5f5f5; font-weight:bold; border:1px solid #ddd;">Date de décision</td>
                <td style="padding:6px 10px; border:1px solid #ddd;">{self.decision_date}</td>
            </tr>
        </table>
        {note_block}
        <p style="margin-top:24px;">
            Cordialement,<br/>
            <strong>{decideur}</strong>
        </p>
    </div>"""    
    
    # def _send_template_email(self, template_xml_id):
    #     template = self.env.ref(template_xml_id, raise_if_not_found=False)
    #     if not template:
    #         return
    #     for rec in self:
    #         try:
    #             # Rendre le corps et le sujet manuellement
    #             body_rendered = template._render_template(
    #                 template.body_html, template.model, rec.ids
    #             )[rec.id]
    #             subject_rendered = template._render_template(
    #                 template.subject, template.model, rec.ids
    #             )[rec.id]
    #             email_to_rendered = template._render_template(
    #                 template.email_to, template.model, rec.ids
    #             )[rec.id]
    
    #             mail_values = {
    #                 'subject':      subject_rendered,
    #                 'body_html':    body_rendered,
    #                 'email_to':     email_to_rendered,
    #                 'email_from':   rec.env.user.email or '',
    #                 'message_type': 'email',
    #                 'state':        'outgoing',
    #             }
    #             mail = rec.env['mail.mail'].sudo().create(mail_values)
    #             mail.sudo().send()
    
    #         except Exception as e:
    #             rec.message_post(body="Echec envoi email : %s" % str(e))
    
    
    def _send_email_submitted(self):
        for rec in self:
            try:
                group = rec.env.ref('qc_pipeline_opportunity.group_validator')
                email_to = ','.join([u.email for u in group.users if u.email])
                if not email_to:
                    continue
                mail = rec.env['mail.mail'].sudo().create({
                    'subject':      f'[Validation requise] {rec.title}',
                    'body_html':    rec._build_html_submitted(),
                    'email_to':     email_to,
                    'email_from':   rec.env.user.email or '',
                    'message_type': 'email',
                    'state':        'outgoing',
                })
                mail.sudo().send()
            except Exception as e:
                rec.message_post(body=f"Échec envoi email soumission : {e}")


    def _send_email_decision(self):
        for rec in self:
            try:
                group_manager = rec.env.ref('qc_pipeline_opportunity.group_opportunity_manager')
                group_validator = rec.env.ref('qc_pipeline_opportunity.group_validator')
                email_to = ','.join([
                    u.email for u in group_manager.users
                    if u.email and group_validator not in u.groups_id
                ])
                if not email_to:
                    continue
                decision_label = 'GO' if rec.go else 'NO-GO'
                mail = rec.env['mail.mail'].sudo().create({
                    'subject':      f'[Décision : {decision_label}] {rec.title}',
                    'body_html':    rec._build_html_decision(),
                    'email_to':     email_to,
                    'email_from':   rec.decision_by.email or rec.env.user.email or '',
                    'message_type': 'email',
                    'state':        'outgoing',
                })
                mail.sudo().send()
            except Exception as e:
                rec.message_post(body=f"Échec envoi email décision : {e}")
                
    # ==========================================================================
    # Actions du workflow
    # ==========================================================================

    def action_submit(self):
        """Opportunity Manager soumet ET notifie le Validator en un clic."""
        for rec in self:
            if rec.state != 'new':
                raise UserError(
                    "Seules les opportunités à l'état 'Nouveau' peuvent être soumises."
                )
            rec.write({'state': 'submitted'})
            rec.message_post(
                body="📨 <b>Soumise pour validation.</b> En attente de décision du validateur."
            )
        self._send_email_submitted()

    # def action_go(self):
    #     """Validator valide : GO."""
    #     for rec in self:
    #         if rec.state != 'submitted':
    #             raise UserError(
    #                 "La décision GO n'est possible que sur une opportunité soumise."
    #             )
    #         rec.sudo().write({
    #             'state':         'go_ok',
    #             'go':            True,
    #             'no_go':         False,
    #             'decision_date': fields.Datetime.now(),
    #             'decision_by':   rec.env.user.id,
    #         })
    #         rec.message_post(
    #             body="✅ <b>Décision : GO.</b> L'équipe peut être assignée."
    #         )
    #     group_manager = self.env.ref('qc_pipeline_opportunity.group_opportunity_manager')
    #     group_validator = self.env.ref('qc_pipeline_opportunity.group_validator')
    #     recipients = [
    #         u.email for u in group_manager.users
    #         if u.email and group_validator not in u.groups_id
    #     ]
    #     self[0].message_post(
    #         body="DEBUG destinataires décision : %s" % str(recipients)
    #     )    
    #     self._send_email_decision()
    
    def action_go(self):
        """Validator valide : GO."""
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(
                    "La décision GO n'est possible que sur une opportunité soumise."
                )
            rec.sudo().write({
                'state':         'go_ok',
                'go':            True,
                'no_go':         False,
                'decision_date': fields.Datetime.now(),
                'decision_by':   rec.env.user.id,
            })
            rec.message_post(
                body="✅ <b>Décision : GO.</b> L'équipe peut être assignée."
            )
        self._send_email_decision()

    def action_no_go(self):
        """Validator rejette : NO-GO."""
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(
                    "La décision NO-GO n'est possible que sur une opportunité soumise."
                )
            rec.sudo().write({
                'state':         'refused',
                'go':            False,
                'no_go':         True,
                'decision_date': fields.Datetime.now(),
                'decision_by':   rec.env.user.id,
            })
            rec.message_post(
                body="❌ <b>Décision : NO-GO.</b> Opportunité classée Non suivi."
            )
        self._send_email_decision() 
        

    def action_register_pipeline(self):
        """
        Enregistre l'opportunité dans le QC Pipeline.
        Crée une entrée qc.opportunity pré-remplie via create_from_identification.
        """
        for rec in self:
            if rec.state != 'go_ok':
                raise UserError(
                    "L'enregistrement en pipeline n'est possible qu'après un GO."
                )
            if not rec.lead_ids:
                raise UserError(
                    "Veuillez assigner au moins un Lead avant d'enregistrer dans la pipeline."
                )
            if not rec.qc_pipeline_id:
                # ── Délégation au modèle qc.opportunity ──────────────────────
                pipeline = rec.env['qc.opportunity'].create_from_identification(rec.id)
                rec.qc_pipeline_id = pipeline.id

            rec.write({'state': 'pipeline_registered'})
            rec.message_post(
                body="🚀 <b>Enregistrée dans la QC Pipeline.</b> Code : %s"
                     % (rec.qc_pipeline_id.opportunity_code or str(rec.qc_pipeline_id.id))
            )

    def action_reset_to_new(self):
        """Remet en brouillon depuis submitted ou refused."""
        for rec in self:
            if rec.state not in ('submitted', 'refused'):
                raise UserError(
                    "Impossible de réinitialiser depuis l'état '%s'." % rec.state
                )
            rec.write({
                'state': 'new',
                'go':    False,
                'no_go': False,
            })
            rec.message_post(body="🔄 Remis en brouillon.")

    def action_open_pipeline(self):
        """Bouton stat : ouvre la fiche QC Pipeline liée."""
        self.ensure_one()
        if not self.qc_pipeline_id:
            raise UserError("Aucun QC Pipeline lié à cette opportunité.")
        return {
            'type':      'ir.actions.act_window',
            'res_model': 'qc.opportunity',
            'res_id':    self.qc_pipeline_id.id,
            'view_mode': 'form',
            'target':    'current',
        }
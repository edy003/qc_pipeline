# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError, UserError


class OpportunityIdentification(models.Model):
    _name = 'opportunity.identification'
    _description = 'Identification & Validation des Opportunités'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'deadline asc'

    # ── Identification ─────────────────────────────────────────────────────────
    category = fields.Selection([
        ('rfp',  'RFP'),
        ('reoi', 'REOI'),
        ('ami',  'AMI'),
        ('ddp',  'DDP'),
    ], string='Category', required=True, tracking=True)

    opportunity_type = fields.Selection([
        ('tc', 'Technologie (TC)'),
        ('co', 'Consulting (CO)'),
        ('fo', 'Formation (FO)'),
    ], string='Type', required=True, tracking=True)

    location           = fields.Many2one('res.country', string='Location', required=True)
    due_date           = fields.Date(string='Due Date', required=True, tracking=True)
    title              = fields.Char(string='Title', required=True)
    client             = fields.Char(string='Client', required=True)
    funding_partner    = fields.Char(string='Funding Partner')
    drive_link         = fields.Char(string='Documents')
    deadline           = fields.Date(string='Deadline', required=True, tracking=True)
    comments           = fields.Text(string='Comments')

    # ── Décision ───────────────────────────────────────────────────────────────
    go    = fields.Boolean(string='Go',    default=False, tracking=True, readonly=True)
    no_go = fields.Boolean(string='No-Go', default=False, tracking=True, readonly=True)

    decision_note = fields.Text(string='Note de décision')
    decision_date = fields.Datetime(string='Date de décision', readonly=True)
    decision_by   = fields.Many2one('res.users', string='Décidé par', readonly=True)

    # ── Assignees ──────────────────────────────────────────────────────────────
    lead_ids = fields.Many2many(
        'hr.employee', 'opp_lead_rel', 'opp_id', 'employee_id',
        string='Leads', tracking=True,
    )
    bd_assistant_ids = fields.Many2many(
        'hr.employee', 'opp_bd_rel', 'opp_id', 'employee_id',
        string='BD Assistants', tracking=True,
    )
    qa_ids = fields.Many2many(
        'hr.employee', 'opp_qa_rel', 'opp_id', 'employee_id',
        string='QA', tracking=True,
    )

    # ── Lien vers le QC Pipeline ───────────────────────────────────────────────
    qc_pipeline_id = fields.Many2one(
        'qc.opportunity', string='QC Pipeline', readonly=True,
    )

    # ── État du workflow ───────────────────────────────────────────────────────
    state = fields.Selection([
        ('new',                 'Nouveau'),
        ('submitted',           'En attente de validation'),
        ('go_ok',               'Go – En attente d\'assignation'),
        ('refused',             'Non suivi'),
        ('pipeline_registered', 'Enregistré dans la Pipeline'),
    ], default='new', tracking=True, string='Statut', readonly=True, copy=False)

    # ── Champ calculé : assignation complète ? ────────────────────────────────
    is_assigned = fields.Boolean(
        string='Équipe assignée',
        compute='_compute_is_assigned',
        store=True,
    )

    @api.depends('lead_ids')
    def _compute_is_assigned(self):
        for rec in self:
            rec.is_assigned = bool(rec.lead_ids)

    # ── Contrainte : go et no_go mutuellement exclusifs ───────────────────────
    @api.constrains('go', 'no_go')
    def _check_decision(self):
        for rec in self:
            if rec.go and rec.no_go:
                raise ValidationError(
                    "Go et No-Go ne peuvent pas être actifs simultanément."
                )

    # ==========================================================================
    # Actions du workflow
    # ==========================================================================

    def action_submit(self):
        """Opportunity Manager soumet l'opportunité pour validation."""
        for rec in self:
            if rec.state != 'new':
                raise UserError(
                    "Seules les opportunités à l'état 'Nouveau' peuvent être soumises."
                )
            rec.write({'state': 'submitted'})
            rec.message_post(
                body="📨 <b>Soumise pour validation.</b> En attente de décision du validateur."
            )

    def action_go(self):
        """Validator valide : GO."""
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(
                    "La décision GO n'est possible que sur une opportunité soumise."
                )
            rec.sudo().write({
                'state':         'go_ok',
                'go':            True,
                'no_go':         False,
                'decision_date': fields.Datetime.now(),
                'decision_by':   rec.env.user.id,
            })
            rec.message_post(
                body="✅ <b>Décision : GO.</b> L'équipe peut être assignée."
            )

    def action_no_go(self):
        """Validator rejette : NO-GO."""
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(
                    "La décision NO-GO n'est possible que sur une opportunité soumise."
                )
            rec.sudo().write({
                'state':         'refused',
                'go':            False,
                'no_go':         True,
                'decision_date': fields.Datetime.now(),
                'decision_by':   rec.env.user.id,
            })
            rec.message_post(
                body="❌ <b>Décision : NO-GO.</b> Opportunité classée Non suivi."
            )

    def action_register_pipeline(self):
        """
        Enregistre l'opportunité dans le QC Pipeline.
        Crée une entrée qc.opportunity pré-remplie via create_from_identification.
        """
        for rec in self:
            if rec.state != 'go_ok':
                raise UserError(
                    "L'enregistrement en pipeline n'est possible qu'après un GO."
                )
            if not rec.lead_ids:
                raise UserError(
                    "Veuillez assigner au moins un Lead avant d'enregistrer dans la pipeline."
                )
            if not rec.qc_pipeline_id:
                # ── Délégation au modèle qc.opportunity ──────────────────────
                pipeline = rec.env['qc.opportunity'].create_from_identification(rec.id)
                rec.qc_pipeline_id = pipeline.id

            rec.write({'state': 'pipeline_registered'})
            rec.message_post(
                body="🚀 <b>Enregistrée dans la QC Pipeline.</b> Code : %s"
                     % (rec.qc_pipeline_id.opportunity_code or str(rec.qc_pipeline_id.id))
            )

    def action_reset_to_new(self):
        """Remet en brouillon depuis submitted ou refused."""
        for rec in self:
            if rec.state not in ('submitted', 'refused'):
                raise UserError(
                    "Impossible de réinitialiser depuis l'état '%s'." % rec.state
                )
            rec.write({
                'state': 'new',
                'go':    False,
                'no_go': False,
            })
            rec.message_post(body="🔄 Remis en brouillon.")

    def action_open_pipeline(self):
        """Bouton stat : ouvre la fiche QC Pipeline liée."""
        self.ensure_one()
        if not self.qc_pipeline_id:
            raise UserError("Aucun QC Pipeline lié à cette opportunité.")
        return {
            'type':      'ir.actions.act_window',
            'res_model': 'qc.opportunity',
            'res_id':    self.qc_pipeline_id.id,
            'view_mode': 'form',
            'target':    'current',
        }
# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError


# ─────────────────────────────────────────────────────────────────────────────
# Constantes partagées
# ─────────────────────────────────────────────────────────────────────────────

ENTITY_CODE = {
    'qc_ghana':         'GH',
    'qc_senegal':       'SN',
    'qc_cameroon':      'CM',
    'qc_cote_ivoire':   'CI',
    'qc_togo':          'TG',
    'qc_nigeria':       'NG',
    'qc_united_states': 'US',
    'qc_mauritius':     'MU',
}

DOMAIN_SELECTION = [
    ('tc', 'Technologie (TC)'),
    ('co', 'Consulting (CO)'),
    ('fo', 'Formation (FO)'),
]

PRACTICE_TC = [
    ('tc_asp', 'TC_ASP : Services d’application, solution et produit'),
    ('tc_ims', 'TC_IMS : Services d’infrastructures'),
]

PRACTICE_CO = [
    ('co_btr', "CO_BTR : Transformation d'entreprise (Entreprise)"),
    ('co_dit', 'CO_DIT : Transformation digitale et informatique'),
    ('co_ars', "CO_ARS : Audit, risque informatique et sécurité de l'information"),
    ('co_apt', "CO_APT : Agilité d'entreprise et transformation de projets"),
    ('co_dai', 'CO_DAI : Données, analyses et IA'),
]

PRACTICE_FO = [
    ('fo_srv', 'FO_SRV : Prestations de formation'),
]

PHASE_STATUS = [
    ('not_started', 'Non démarré'),
    ('in_progress',  'En cours'),
    ('submitted',    'Soumis'),
    ('done',         'Terminé'),
    ('cancelled',    'Annulé'),
]

RESULT_SELECTION = [
    ('success', 'Succès'),
    ('failure', 'Échec'),
]

YES_NO = [
    ('yes', 'Oui'),
    ('no',  'Non'),
]


class QcOpportunity(models.Model):
    _name        = 'qc.opportunity'
    _description = 'QC Pipeline – Opportunité'
    _inherit     = ['mail.thread', 'mail.activity.mixin']
    _order       = 'year desc, month desc, id desc'
    _rec_name    = 'opportunity_code'

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 1 — Identification & Lien source
    # ══════════════════════════════════════════════════════════════════════════

    opportunity_id = fields.Many2one(
        'opportunity.identification',
        string='Opportunité source',
        readonly=True,
        ondelete='restrict',
        help="Renseigné automatiquement si l'opportunité vient du module Identification.",
    )
    # Indique si les données proviennent du module identification
    from_identification = fields.Boolean(
        compute='_compute_from_identification',
        store=True,
    )

    @api.depends('opportunity_id')
    def _compute_from_identification(self):
        for rec in self:
            rec.from_identification = bool(rec.opportunity_id)

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 2 — Champs de base du pipeline
    # ══════════════════════════════════════════════════════════════════════════

    opportunity_code = fields.Char(
        string='Code Opportunité',
        required=True,
        copy=False,
        default='/',
        tracking=True,
        help="Code unique de l'opportunité. Ex : QC-CM-TC-2025-001",
    )

    business_entity = fields.Selection([
    ('qc_ghana', 'Qualisys GHANA'),
    ('qc_senegal', 'Qualisys SENEGAL'),
    ('qc_cameroon', 'Qualisys CAMEROON'),
    ('qc_cote_ivoire', "Qualisys COTE-D'IVOIRE"),
    ('qc_togo', 'Qualisys TOGO'),
    ('qc_nigeria', 'Qualisys NIGERIA'),
    ('qc_united_states', 'Qualisys UNITED STATES'),
    ('qc_mauritius', 'Qualisys MAURITIUS'),
    ], string="Entité d'affaire", required=True, tracking=True)

    # ── Titre ─────────────────────────────────────────────────────────────────
    # Hérité de title dans opportunity.identification si source connue
    opportunity_name = fields.Char(
        string='Opportunité (Mission/Projet)',
        required=True,
        tracking=True,
    )

    # ── Référence de l'appel ─────────────────────────────────────────────────
    notice_reference = fields.Char(
        string="Référence de l'appel",
        tracking=True,
    )

    # ── Domaine / Area ────────────────────────────────────────────────────────
    domain_area = fields.Selection(
        DOMAIN_SELECTION,
        string='Domaine / Area',
        required=True,
        tracking=True,
    )

    practice_tc = fields.Selection(
    PRACTICE_TC,
    string='Practice TC',
    tracking=True,
    )
    practice_co = fields.Selection(
        PRACTICE_CO,
        string='Practice CO',
        tracking=True,
    )
    practice_fo = fields.Selection(
        PRACTICE_FO,
        string='Practice FO',
        tracking=True,
    )

    # Champ unifié lu partout dans le code (code opport., exports, etc.)
    practice = fields.Char(
        string='Practice',
        compute='_compute_practice',
        store=True,
    )

    @api.depends('domain_area', 'practice_tc', 'practice_co', 'practice_fo')
    def _compute_practice(self):
        for rec in self:
            if rec.domain_area == 'tc':
                rec.practice = rec.practice_tc or False
            elif rec.domain_area == 'co':
                rec.practice = rec.practice_co or False
            elif rec.domain_area == 'fo':
                rec.practice = 'fo_srv'
            else:
               rec.practice = False

    @api.onchange('domain_area')
    def _onchange_domain_area(self):
        self.practice_tc = False
        self.practice_co = False
        self.practice_fo = False
        if self.domain_area == 'fo':
            self.practice_fo = 'fo_srv'
            
  
    # ── Responsables de production ────────────────────────────────────────────
    # Héritent des assignees de opportunity.identification si source connue.
    # Sinon, saisie libre Many2many vers hr.employee.
    lead_ids = fields.Many2many(
        'hr.employee',
        'qc_opp_lead_rel', 'qc_opp_id', 'employee_id',
        string='Leads',
        tracking=True,
    )
    bd_assistant_ids = fields.Many2many(
        'hr.employee',
        'qc_opp_bd_rel', 'qc_opp_id', 'employee_id',
        string='BD Assistants',
        tracking=True,
    )
    qa_ids = fields.Many2many(
        'hr.employee',
        'qc_opp_qa_rel', 'qc_opp_id', 'employee_id',
        string='QA',
        tracking=True,
    )

    # ── Année / Mois ──────────────────────────────────────────────────────────
    year = fields.Integer(
        string='Année',
        required=True,
        default=lambda self: fields.Date.today().year,
        tracking=True,
    )
    MONTH_SELECTION = [
    ('1',  'Janvier'),  ('2',  'Février'),  ('3',  'Mars'),
    ('4',  'Avril'),    ('5',  'Mai'),       ('6',  'Juin'),
    ('7',  'Juillet'),  ('8',  'Août'),      ('9',  'Septembre'),
    ('10', 'Octobre'),  ('11', 'Novembre'),  ('12', 'Décembre'),
    ]
    
    month = fields.Selection(
    MONTH_SELECTION,
    string='Mois',
    required=True,
    default=lambda self: str(fields.Date.today().month),
    tracking=True,
    )

    # ── Pays ──────────────────────────────────────────────────────────────────
    country_id = fields.Many2one(
        'res.country',
        string='Pays opportunité',
        required=True,
        tracking=True,
    )

    # ── Type d'opportunité ───────────────────────────────────────────────────
    opportunity_type = fields.Selection([
        ('rfp',  'RFP'),
        ('reoi', 'REOI'),
        ('ami',  'AMI'),
        ('ddp',  'DDP'),
    ], string="Type d'opportunité", required=True, tracking=True)

    # ── Méthode de sélection ─────────────────────────────────────────────────
    selection_method = fields.Selection([
    ('scq', 'Sélection basée sur les qualifications des consultants (SCQ)'),
    ('qs', 'Sélection basée sur la qualité (QS)'),
    ('scbd', 'Sélection dans le cadre d’un budget déterminé (SCBD)'),
    ('sqc', 'Sélection basée sur la qualité et le coût (SQC)'),
    ('smc', 'Sélection au moindre coût (SMC)'),
    ], string='Méthode de sélection', tracking=True)

    # ── Bailleur de fonds ────────────────────────────────────────────────────
    funding_partner = fields.Char(
        string='Bailleur de fonds',
        tracking=True,
    )

    # ── Budget planifié ──────────────────────────────────────────────────────
    planned_budget = fields.Monetary(
        string='Budget planifié',
        currency_field='currency_id',
        tracking=True,
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Devise',
        default=lambda self: self.env.company.currency_id,
    )

    # ── Organisme / Client ───────────────────────────────────────────────────
    client_name = fields.Char(
        string='Organisme (Client)',
        tracking=True,
    )

    # ── Mode de soumission ───────────────────────────────────────────────────
    submission_mode = fields.Selection([
        ('electronic', 'Électronique'),
        ('physical',   'Physique'),
    ], string='Mode de soumission', tracking=True)

    # ── Contacts pour la soumission ──────────────────────────────────────────
    submission_contacts = fields.Text(
        string='Contacts pour la soumission',
        help="Noms, emails, téléphones et rôles des contacts pour la soumission.",
    )

    # ── Dates ─────────────────────────────────────────────────────────────────
    publication_date    = fields.Date(string='Date de publication',   tracking=True)
    preparation_start   = fields.Date(string='Date début préparation', tracking=True)

    # ── Drive Link ────────────────────────────────────────────────────────────
    drive_link = fields.Char(
        string='Drive Link',
        help="Lien vers le dossier Drive contenant les documents de l'opportunité.",
    )

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 3 — Partenaires & Porteurs d'affaires (→ res.partner)
    # ══════════════════════════════════════════════════════════════════════════

    partner_ids = fields.Many2many(
        'res.partner',
        'qc_opp_partner_rel', 'qc_opp_id', 'partner_id',
        string='Partenaires',
        domain=[('is_company', '=', True)],
        tracking=True,
    )

    business_facilitator_ids = fields.Many2many(
        'res.partner',
        'qc_opp_facilitator_rel', 'qc_opp_id', 'partner_id',
        string="Porteurs d'affaires (Facilitateurs)",
        tracking=True,
    )

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 4 — Leçons apprises & Notes globales
    # ══════════════════════════════════════════════════════════════════════════

    lessons_learned = fields.Text(string='Leçons apprises')

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 5 — Workflow principal
    # ══════════════════════════════════════════════════════════════════════════

    state = fields.Selection([
        ('preparation',        'En préparation'),
        ('in_submission',      'Soumission en cours'),
        ('in_proposition',     'Proposition en cours'),
        ('in_contractual',     'Contractualisation en cours'),
        ('won',                'Gagné'),
        ('lost',               'Perdu'),
        ('cancelled',          'Annulé'),
    ], string='Statut', default='preparation', required=True,
       tracking=True, copy=False)

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 6 — Phase Soumission
    # ══════════════════════════════════════════════════════════════════════════

    closing_deadline = fields.Date(
        string='Date de clôture soumission',
        tracking=True,
    )
    submission_phase_status = fields.Selection(
        PHASE_STATUS,
        string='Statut soumission',
        default='not_started',
        tracking=True,
    )
    submission_result_date  = fields.Date(string='Date prévue réception résultats')
    submission_result       = fields.Selection(RESULT_SELECTION, string='Résultats soumission', tracking=True)
    submission_notes        = fields.Text(string='Notes soumission')

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 7 — Phase Proposition
    # ══════════════════════════════════════════════════════════════════════════

    # — Proposition Technique —
    has_technical_proposal  = fields.Selection(YES_NO, string='Proposition Technique à soumettre ?')
    tp_closing_date         = fields.Date(string='Date clôture PT')
    tp_status               = fields.Selection(PHASE_STATUS, string='Statut PT', default='not_started')
    tp_opening_date         = fields.Date(string='Date ouverture PT')
    tp_result_date          = fields.Date(string='Date prévue résultats PT')
    tp_result               = fields.Selection(RESULT_SELECTION, string='Résultats PT', tracking=True)
    tp_score                = fields.Float(string='Note PT /100', digits=(5, 2))
    tp_notes                = fields.Text(string='Notes PT')

    # — Proposition Financière —
    has_financial_proposal  = fields.Selection(YES_NO, string='Proposition Financière à soumettre ?')
    fp_closing_date         = fields.Date(string='Date clôture PF')
    fp_status               = fields.Selection(PHASE_STATUS, string='Statut PF', default='not_started')
    fp_opening_date         = fields.Date(string='Date ouverture PF')
    fp_result_date          = fields.Date(string='Date prévue résultats PF')
    fp_result               = fields.Selection(RESULT_SELECTION, string='Résultats PF', tracking=True)
    fp_score                = fields.Float(string='Note PF /100', digits=(5, 2))
    fp_notes                = fields.Text(string='Notes PF')

    # — Résultat définitif —
    final_result            = fields.Selection(RESULT_SELECTION, string='Résultat Définitif', tracking=True)
    final_score             = fields.Float(string='Note finale /100', digits=(5, 2))
    proposition_phase_status = fields.Selection(
        PHASE_STATUS,
        string='Statut phase proposition',
        default='not_started',
        tracking=True,
    )

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 8 — Phase Contractualisation
    # ══════════════════════════════════════════════════════════════════════════

    contractual_status       = fields.Selection(PHASE_STATUS, string='Statut contractualisation', default='not_started', tracking=True)
    contractual_effect_date  = fields.Date(string="Date d'effet")
    contractual_notes        = fields.Text(string='Notes contractualisation')

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 9 — Champs calculés / techniques
    # ══════════════════════════════════════════════════════════════════════════

    submission_tab_visible    = fields.Boolean(compute='_compute_tab_visibility', store=True)
    proposition_tab_visible   = fields.Boolean(compute='_compute_tab_visibility', store=True)
    contractual_tab_visible   = fields.Boolean(compute='_compute_tab_visibility', store=True)

    @api.depends('state')
    def _compute_tab_visibility(self):
        submission_states    = {'in_submission', 'in_proposition', 'in_contractual', 'won', 'lost'}
        proposition_states   = {'in_proposition', 'in_contractual', 'won', 'lost'}
        contractual_states   = {'in_contractual', 'won', 'lost'}
        for rec in self:
            rec.submission_tab_visible  = rec.state in submission_states
            rec.proposition_tab_visible = rec.state in proposition_states
            rec.contractual_tab_visible = rec.state in contractual_states

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 10 — Onchange : practice reset si domaine change
    # ══════════════════════════════════════════════════════════════════════════

    def _generate_opportunity_code(self):
        self.ensure_one()
    
        entity_code  = ENTITY_CODE.get(self.business_entity, 'XX')
        country_code = self.country_id.code.upper() if self.country_id else 'XX'
        practice_code = (self.practice or 'XX').upper().replace('_', '-')
        year  = str(self.year)
        month = str(self.month).zfill(2)

        # Séquence globale sur le mois/année — exclut l'enregistrement courant
        existing_count = self.env['qc.opportunity'].search_count([
            ('year',  '=', self.year),
            ('month', '=', self.month),
            ('opportunity_code', '!=', '/'),
        ])
        sequence = str(existing_count + 1).zfill(2)

        return f"QC-{entity_code}_{country_code}_{practice_code}_{year}-{month}_{sequence}"

    @api.model
    def create(self, vals):
        rec = super().create(vals)
        if rec.opportunity_code == '/':
            rec.opportunity_code = rec._generate_opportunity_code()
        return rec
    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 11 — Contraintes
    # ══════════════════════════════════════════════════════════════════════════

    @api.constrains('tp_score', 'fp_score', 'final_score')
    def _check_scores(self):
        for rec in self:
            for score, label in [
                (rec.tp_score,    'Note PT'),
                (rec.fp_score,    'Note PF'),
                (rec.final_score, 'Note finale'),
            ]:
                if score and not (0 <= score <= 100):
                    raise ValidationError(f"{label} doit être comprise entre 0 et 100.")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 12 — Actions du workflow principal
    # ══════════════════════════════════════════════════════════════════════════

    def action_start_submission(self):
        """En préparation → Soumission en cours."""
        for rec in self:
            if rec.state != 'preparation':
                raise UserError("L'opportunité doit être en préparation pour lancer la soumission.")
            rec.write({
                'state': 'in_submission',
                'submission_phase_status': 'in_progress',
            })
            rec.message_post(body="📤 <b>Phase Soumission lancée.</b>")

    def action_start_proposition(self):
        """Soumission → Proposition en cours. Accessible uniquement si résultat soumission = succès."""
        for rec in self:
            if rec.state != 'in_submission':
                raise UserError("L'opportunité doit être en phase soumission.")
            if rec.submission_result != 'success':
                raise UserError(
                    "Le résultat de la phase soumission doit être 'Succès' pour passer en proposition."
                )
            rec.write({
                'state': 'in_proposition',
                'submission_phase_status': 'done',
                'proposition_phase_status': 'in_progress',
            })
            rec.message_post(body="📋 <b>Phase Proposition lancée.</b>")

    def action_start_contractualisation(self):
        """Proposition → Contractualisation. Accessible si résultat définitif proposition = succès."""
        for rec in self:
            if rec.state != 'in_proposition':
                raise UserError("L'opportunité doit être en phase proposition.")
            if rec.final_result != 'success':
                raise UserError(
                    "Le résultat définitif de la phase proposition doit être 'Succès' pour contractualiser."
                )
            rec.write({
                'state': 'in_contractual',
                'proposition_phase_status': 'done',
                'contractual_status': 'in_progress',
            })
            rec.message_post(body="📝 <b>Phase Contractualisation lancée.</b>")

    def action_mark_won(self):
        """Contractualisation → Gagné."""
        for rec in self:
            if rec.state != 'in_contractual':
                raise UserError("L'opportunité doit être en phase contractualisation pour être marquée Gagnée.")
            rec.write({
                'state': 'won',
                'contractual_status': 'done',
            })
            rec.message_post(body="🏆 <b>Opportunité GAGNÉE !</b>")

    def action_mark_lost(self):
        """Marquer comme Perdu depuis n'importe quelle phase active."""
        for rec in self:
            if rec.state in ('won', 'lost', 'cancelled', 'preparation'):
                raise UserError("Impossible de marquer cette opportunité comme Perdue depuis son état actuel.")
            rec.write({'state': 'lost'})
            rec.message_post(body="❌ <b>Opportunité marquée PERDUE.</b>")

    def action_cancel(self):
        """Annuler l'opportunité."""
        for rec in self:
            if rec.state in ('won', 'lost', 'cancelled'):
                raise UserError("Impossible d'annuler une opportunité déjà clôturée.")
            rec.write({'state': 'cancelled'})
            rec.message_post(body="🚫 <b>Opportunité annulée.</b>")

    def action_reset_to_preparation(self):
        """Remettre en préparation depuis annulé ou perdu (correction)."""
        for rec in self:
            if rec.state not in ('cancelled', 'lost'):
                raise UserError("Seules les opportunités annulées ou perdues peuvent être réouvertes.")
            rec.write({
                'state': 'preparation',
                'submission_phase_status': 'not_started',
                'proposition_phase_status': 'not_started',
                'contractual_status': 'not_started',
            })
            rec.message_post(body="🔄 <b>Opportunité réouverte en préparation.</b>")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 13 — Création : héritage automatique depuis opportunity.identification
    # ══════════════════════════════════════════════════════════════════════════

    @api.model
    def create_from_identification(self, identification_id):
        """
        Appelé par opportunity.identification.action_register_pipeline.
        Crée un qc.opportunity pré-rempli depuis la fiche d'identification.
        """
        src = self.env['opportunity.identification'].browse(identification_id)
        if not src.exists():
            raise UserError("Fiche d'identification introuvable.")
    
        vals = {
            # ── Lien source ───────────────────────────────────────────────
            'opportunity_id':       src.id,
            'from_identification':  True,        # forcer pour éviter le False au premier affichage
    
            # ── Champs hérités (mapping exact) ────────────────────────────
            'opportunity_name':     src.title,
            'domain_area':          src.opportunity_type,   # TC / CO / FO
            'country_id':           src.location.id if src.location else False,
            'opportunity_type':     src.category,           # RFP / REOI / AMI / DDP
            'funding_partner':      src.funding_partner or '',
            'client_name':          src.client or '',
            'drive_link':           src.drive_link or '',
    
            # ── Équipe héritée ────────────────────────────────────────────
            'lead_ids':             [(6, 0, src.lead_ids.ids)],
            'bd_assistant_ids':     [(6, 0, src.bd_assistant_ids.ids)],
            'qa_ids':               [(6, 0, src.qa_ids.ids)],
    
            # ── État initial obligatoire ──────────────────────────────────
            'state':                'preparation',
        }
        return self.create(vals)

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 14 — Enregistrement des partenaires dans res.partner
    # ══════════════════════════════════════════════════════════════════════════

    def _ensure_partner_tag(self, tag_name):
        """Récupère ou crée un tag res.partner.category."""
        tag = self.env['res.partner.category'].search([('name', '=', tag_name)], limit=1)
        if not tag:
            tag = self.env['res.partner.category'].create({'name': tag_name})
        return tag

    def action_open_source_identification(self):
        """Bouton stat : ouvre la fiche opportunity.identification source."""
        self.ensure_one()
        if not self.opportunity_id:
            raise UserError("Aucune fiche d'identification liée à cette opportunité.")
        return {
            'type':      'ir.actions.act_window',
            'res_model': 'opportunity.identification',
            'res_id':    self.opportunity_id.id,
            'view_mode': 'form',
            'target':    'current',
        }

    def action_sync_partners_to_contacts(self):
        """
        Tague les partenaires et porteurs d'affaires liés
        dans res.partner pour les rendre visibles dans les contacts globaux.
        """
        partner_tag     = self._ensure_partner_tag('Partenaire QC Pipeline')
        facilitator_tag = self._ensure_partner_tag("Porteur d'affaires QC")

        for rec in self:
            for partner in rec.partner_ids:
                partner.category_id = [(4, partner_tag.id)]

            for facilitator in rec.business_facilitator_ids:
                facilitator.category_id = [(4, facilitator_tag.id)]

        self.message_post(
            body="🔗 <b>Partenaires et porteurs d'affaires synchronisés dans les contacts.</b>"
        )
# models/res_partner_patch.py
from odoo import models, fields

class ResPartnerPatch(models.Model):
    _inherit = 'res.partner'
    
    partner_gid = fields.Integer('Company database ID', default=0)
    additional_info = fields.Char('Additional info')
# -*- coding: utf-8 -*-
from . import qc_opportunity  
from . import opportunity_identification

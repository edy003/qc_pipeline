# -*- coding: utf-8 -*-
from . import qc_opportunity  
from . import opportunity_identification
from . import res_partner_patch

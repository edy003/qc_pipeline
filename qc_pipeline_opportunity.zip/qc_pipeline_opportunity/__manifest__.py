# -*- coding: utf-8 -*-
{
    'name': "QC Pipeline – Gestion des Opportunités",
    'summary': "Identification, validation et enregistrement des opportunités dans le QC Pipeline.",
    'description': """
        Module de gestion du pipeline d'opportunités Qualisys.
        - Phase 1 : Identification & soumission (Opportunity Manager)
        - Phase 2 : Décision Go / No-Go (Validator)
        - Phase 3 : Assignation de l'équipe (Manager ou Validator)
        - Phase 4 : Enregistrement dans le QC Pipeline
    """,
    'author': "Qualisys",
    'website': "https://www.qualisys.com",
    'category': 'Project',
    'version': '16.0.1.0.0',

    'depends': ['base', 'hr', 'mail'],

    'data': [
        # 1. Groupes de sécurité en premier
        # 'security/res_groups.xml',
        'security/security.xml',
        # 2. Droits d'accès
        'security/ir.model.access.csv',
        # 3. Règles sur les enregistrements
        # 'security/record_rules.xml',
        # 4. Vues (form + list + kanban + search + action + menu — TOUT dans un seul fichier)
        'views/qc_opportunity_views.xml',
        'views/opportunity_views.xml',
    ],

    'installable': True,
    'application': True,
    'auto_install': False,
}
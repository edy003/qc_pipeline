# -*- coding: utf-8 -*-
# from odoo import http


# class QcPipelineOpportunity(http.Controller):
#     @http.route('/qc_pipeline_opportunity/qc_pipeline_opportunity', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/qc_pipeline_opportunity/qc_pipeline_opportunity/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('qc_pipeline_opportunity.listing', {
#             'root': '/qc_pipeline_opportunity/qc_pipeline_opportunity',
#             'objects': http.request.env['qc_pipeline_opportunity.qc_pipeline_opportunity'].search([]),
#         })

#     @http.route('/qc_pipeline_opportunity/qc_pipeline_opportunity/objects/<model("qc_pipeline_opportunity.qc_pipeline_opportunity"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('qc_pipeline_opportunity.object', {
#             'object': obj
#         })
